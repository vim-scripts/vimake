#include <stdio.h>

int inf(){
	printf("\n\tVIMAKE MIXED LANGUAGE DEMONSTRATION // c function\n\n");
return(0);
}
