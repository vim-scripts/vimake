#include <stdio.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/utsname.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>

int  id(void){
	struct passwd   *pw;
	struct hostent	*hptr;
	struct utsname  myname;
	char			**pptr;
	char			str[16];


	pw = getpwuid(getuid());  
	endpwent();

	if (uname(&myname) < 0)
		return(0);
	if ( (hptr = gethostbyname(myname.nodename)) == NULL)
		return(0);
	printf("\tProcess id:        %ld\n",(long)getpid());
	printf("\tParent Process id: %ld\n",(long)getppid());
	printf("\tUser Name:         %s\n",pw->pw_name);
	printf("\tOwner Group id:    %ld\n",(long)getgid());
	printf("\tOwner User  id:    %ld\n",(long)getuid());
	printf("\tUser Shell:        %s\n",pw->pw_shell);
	printf("\tHome Directory:    %s\n",pw->pw_dir);
	printf("\tFull Name:         %s\n",pw->pw_gecos);

	printf("\tHostname: \t   %s\n", hptr->h_name);
		switch (hptr->h_addrtype) {
		case AF_INET: pptr = hptr->h_addr_list;
					for ( ; *pptr != NULL; pptr++)
	printf("\tIp Address:        %s\n",inet_ntop(hptr->h_addrtype,*pptr,str,sizeof(str)));
					break;
		default:	fprintf (stderr,"\tunknown address type");
					break;
					}
	for (pptr = hptr->h_aliases; *pptr != NULL; pptr++)
	printf("\tAlias:             %s\n", *pptr);
	
	return(0);
}
