#ifndef __VIDBG__H
#define __VIDBG__H
// =====================================================================================
// 
//       Filename:  vdebug.h
// 
//    Description:  Header File for the debug code for vimake
// 
//       $Id: vdebug.h,v 1.4 2010/11/17 20:03:25 mike Exp $
//       $Revision: 1.4 $
// 
//         Author:  Mike Lear mikeofthenight2003@yahoo.com
//	                                                                          
//	 Copyright (C) 2006 Mike Lear <mikeofthenight2003@yahoo.com>              
//	                                                                          
//	 This file is free software; as a special exception the author gives      
//	 unlimited permission to copy and/or distribute it, with or without       
//	 modifications, as long as this notice is preserved.                      
//	                                                                          
//	 This program is distributed in the hope that it will be useful, but      
//	 WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// 
// =====================================================================================


#include 	<map>
#include 	<pwd.h>
#include    <iostream>
#include    <fstream>
#include    <sstream>
#include    <string>
#include 	<algorithm>
#include    <sys/stat.h>
#include    <vector>
#include    <stdexcept>
#include    "utils.h"
#include    "error.h"


namespace   edn {

	using   std::cout;
	using   std::cerr;
	using   std::endl;
	using   std::ends;
	using   std::ifstream;
	using   std::ofstream;
	using   std::ios;
	using   std::string;
	using   std::vector;
	using   std::istringstream;
	using   std::ostringstream;
	using   std::stringstream;
	using	std::out_of_range;

}



namespace edm{
extern bool isXterm;
using namespace edn;	


	enum { 
		 SrcDbgFile, ExeDbgFile, ExtentFile, MDebugger, DbgInitAtt, DbgInitIntel
		 };	   


	class Vidbug : public virtual Utils {  
		protected:
			std::string 	_MainFileSrc;   	
			std::string 	_MainFileObj;   
			std::string 	_MainFileExe;	 	
		public:
			Vidbug(std::string &str);
			virtual auto_ptr <std::string> ReadDebuggers(const std::string& InFileName);
			virtual int Validity(const std::string& InFileName);
			virtual int DebugFile(const std::string& InDbugType);
			virtual int SelectDbg(const std::string& InDebugger);
			virtual int SwitchDbg(const string &InDebugger,const string &InSrcExt,const string &InFileName);
			virtual int GetDbFile(const std::string& InDbExtent);
			Vidbug *operator->() { return this; }
			virtual ~Vidbug() {};
	};

}  // edm namespace
#endif

