// =====================================================================================
// 
//       Filename:  vimrun.cc
// 
//    Description:  Source code for the multi language vim-gvim run program 
//
//          $Id: virun.cc,v 1.2 2010/10/16 22:56:39 mike Exp $
//          $Revision: 1.2 $
// 
//          Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//          Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>            
// 
//          This file is free software; as a special exception the author gives     
//          unlimited permission to copy and/or distribute it, with or without       
//          modifications, as long as this notice is preserved.                      
//
//          This program is distributed in the hope that it will be useful, but      
///          WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//           implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================
//
#include "vrun.h"

bool	edm::isXterm;
using 	namespace edn;
using 	namespace edm;




int main(int argc,char *argv[]){
Error<string> E;	
            

			try {

				auto_ptr <string> tty (new string(getenv("TERM")));
				*tty  == "xterm" ? isXterm = true : isXterm = false;

			if (argc != 2) throw BadFileArgs();
				const auto_ptr < string > FileName (new string (argv[argc - 1]));
				Vrun R(*FileName); 

				unsigned int mIndex = R->Validity (FileName -> c_str()); 
				auto_ptr<string> CmdLine(new string);
				CmdLine = R->ReadBuildConfig ("cmdline.arg");  
				bitset<Keys> FunKey (string(CmdLine->c_str()));
				CmdLine -> clear();

			if (FunKey.test(F3) == true) {
				E->Mesg("\nEnter arguments to command: ");
				getline (std::cin, *CmdLine);
				R->RunName (mIndex, *CmdLine);
				}  else {
				CmdLine -> clear();
				R->RunName (mIndex, *CmdLine);
				}
			} catch (const FileError& e) {
				E->Mesg(e.what(),"\n");
				exit (1);
			} catch ( ... ) {
				E->Quit("unrecognized exception!");
			}


return 0;
}

