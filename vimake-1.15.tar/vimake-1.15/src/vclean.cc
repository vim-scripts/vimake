// =====================================================================================
// 
//       Filename:  vclean.cc
// 
//    Description:  Remove object and executable files from current directory
// 
//         $Id: vclean.cc,v 1.3 2010/11/17 12:52:39 mike Exp $
//         $Revision: 1.3 $
// 
//         Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//		   Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>            
//	                                                                          
//		   This file is free software; as a special exception the author gives      
//	 	   unlimited permission to copy and/or distribute it, with or without       
//		   modifications, as long as this notice is preserved.                      
//	                                                                          
//	 	   This program is distributed in the hope that it will be useful, but      
//	 	   WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	  	   implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================


#include "vclean.h"
extern char **environ;
namespace edm {
using namespace edn;


//--------------------------------------------------------------------------------------
//       Class:  VCLEAN
//      Method:  CONSTRUCTOR
// Description:  Parameter Initialization
//--------------------------------------------------------------------------------------
Vclean::Vclean(std::string &InMainFileName) {

std::string::size_type idx;
std::string FileNameExt;

                _DisplayMode  = 0;
                _MainFileSrc = InMainFileName;
                _MainFileExe  = InMainFileName;
                idx           = InMainFileName.rfind('.');

            if (idx == std::string::npos) {
                throw FileIndexError(InMainFileName);

            } else {
                FileNameExt.assign(_MainFileSrc,idx,_MainFileSrc.size());
                _MainFileExe.erase (idx, FileNameExt.size ());
                }
}

//--------------------------------------------------------------------------------------
//       Class:  VCLEAN
//      Method:  VALIDITY
// Description:  This version of Validity allows the removal of object and
//               executable files only if a valid file type has been loaded
//               whilst in a vimake session. 
//               This is to make it more difficult to remove executable and 
//               object files directly from the command line, although this
//               is not foolproof.
//--------------------------------------------------------------------------------------
int Vclean::Validity(const string& InFileName) {

string      FileExtent;
string      FileName;
string::size_type index;

                FileName = InFileName;
                index    = FileName.rfind('.');
                FileExtent.assign(FileName,++index,FileName.size());
                index    = GetFileExt(FileExtent);
        switch (index) {
            case 1:         // return only known file extension types.
            case 2:         // throw an error for all others.
            case 3:
            case 4:
            case 6:     break;
            default:    throw FileUnknownError(FileName.c_str());
                        break;
            }


return index;
}





//--------------------------------------------------------------------------------------
//       Class:  VCLEAN
//       Member: RemoveObj
// Description:  Remove all object and executable files from current working directory
//--------------------------------------------------------------------------------------
void   Vclean::RemoveObj() {
Error<string> E;
DIR *dp;
struct dirent *direntp;
struct stat statbuf;

				string::size_type index;
                auto_ptr <string> old_file (new string);
				auto_ptr <string> chk_line (new string);
				ifstream fin;


         if ((dp = opendir(".")) == NULL) 			// run in the current working directory
			 throw FileDirError();
            

             while ((direntp = readdir(dp)) != NULL) {

                if (direntp->d_ino == 0)			// skip over removed files (inode = 0)
                    continue;

                if (stat(direntp->d_name,&statbuf) <0) {
                    E->Mesg("Cannot get information on",direntp->d_name,"\n");
                    }
					index=string::npos;
					*old_file = direntp->d_name;
					index = old_file->find(".o");

                if (index != string::npos) {
                    cout << "Removing " << *old_file << endl;
                if (unlink(old_file->c_str()) <0){	// remove object files
                    E->Mesg("Cannot remove",direntp->d_name,"\n");
                    }
                }


                if (statbuf.st_mode &  S_IFDIR)		// skip over any directories
                    continue;

				// BUG FIX:  vclean was removing executable shell scripts!
				// Stat returns true on execuable shell scripts such as perl,python,bash ect
				// Further checks have been added to skip any executable shell scripts.
				// So only compiled executable files and object files are removed.
					index = 0;

                if (statbuf.st_mode &  S_IXUSR) {  // BUG FIX: 
					*old_file = direntp->d_name;   
					fin.open(old_file->c_str(),std::ios::in);

				 if (fin.fail()) { continue;} else {
					getline(fin,*chk_line);
					fin.clear();
					fin.close();
					index = chk_line->find("#!/");

				if (index != string::npos) {	
					continue;
				} 
                    cout << "Removing " << direntp->d_name << endl;
                if (unlink(direntp->d_name) <0){	// remove executable files
                    E->Mesg("Cannot remove",direntp->d_name,"\n");
                    }
				}
			}				        
		}
		closedir(dp);

}






} // namespace edm
