// =====================================================================================
// 
//       Filename:  Luadump.cc
// 
//    Description:  Demonstration hex-ascii, octal-ascii file dump program 
//    				using Lua xdump script to perform the formatted output. 
//
//        $Id: luadump.cc,v 1.1.1.1 2010/10/16 09:10:51 mike Exp $
//        $Revision: 1.1.1.1 $ 
// 
//          Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//          Copyright (C) 2006-10 Mike Lear <mikeofthenight2003@yahoo.com>            
// 
//          This file is free software; as a special exception the author gives     
//          unlimited permission to copy and/or distribute it, with or without       
//          modifications, as long as this notice is preserved.                      
//
//          This program is distributed in the hope that it will be useful, but      
//          WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//          implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================

#include <iostream>
#include <cstdlib>
#include <memory>
#include <sys/stat.h>
#include <stdexcept>
#include "lua.hpp"
using namespace std;


int 	errmsg (lua_State *instance , int);



int main (int argc,char *argv[]) {
struct stat statbuf;



			try {

					auto_ptr < string > script (new string("xdump.bin")); // place the name of the binary lua script in string
 			if (argc != 3) {
	                 *script =  "\n\tUsage:  luadump [ -o | -x ] filename.ext\n";
					 throw invalid_argument (*script);
					}


					auto_ptr < string > fileName (new string (argv[argc - 1]));
                  	auto_ptr < string > option   (new string (argv[argc - 2]));
					
   					lua_State* state = luaL_newstate();    			// inform lua to create a state and
   					luaL_openlibs( state );                			// open necessary lua libraries for access

					string::size_type index = script -> find('.');
			if (stat( script -> c_str(), &statbuf)<0) {	   			// do we have a binary lua script?
					  script -> replace(index, index, ".lua");  	// NO - revert to text version
					  }

			if (stat( script -> c_str(), &statbuf)<0) {	   			// ensure the script can be accessed
					  *fileName = "\n\tError: Cannot find file " + *script;
					  throw invalid_argument (*fileName);
					  }	

					cout << "\n\tLua file type used is " << (*script).c_str() << endl; 	// display script type  
					errmsg (state, luaL_loadfile( state, script -> c_str()));  		    // use lua error checking to load script
					cout << "\n\t[C++] Passing " << option ->c_str() << " and " << fileName -> c_str() 
						 << " to the " << script -> c_str() << " script!" << endl << endl;		// display arguments passed to script
							

					lua_newtable 	(state);                 	 	// create a table  

				for (int idx = 1; idx < 3; lua_rawset (state, -3), ++idx) {	
					lua_pushnumber 	(state, idx);                  	// push option then filename 
					lua_pushfstring (state, option -> c_str());     // on to the stack.
					(*option).swap  (*fileName);                     
				}
					lua_setglobal	(state, "arg");               	
					errmsg (state, lua_pcall (state,0,1,0));       // use (errmsg) lua error checking to run proteced call
					long filesize = lua_tonumber (state, -1);     	// return the filesize for c++ to display
				 
				if (filesize)										// display returned filesize	
					cout << "\n\t[Lua script] returned filesize " << filesize << " bytes, back to [C++]" << endl;
					lua_close (state);								// clean up

			} catch(const invalid_argument& e){
				cerr << e.what() << endl;
			exit (1);
			} catch (...) {
				cerr << "\n\tUndetermined exception occurred!" << endl;
		 	exit (1);
			}


   return 0;
}



//---------------------------------------------------------------------------   
//	  Lua errmsg function: 
//	  errno returns zero if there are no errors.
//---------------------------------------------------------------------------   
int errmsg(lua_State *instance , int errno) {

	if (errno) {
		auto_ptr < string > msg (new string("\n\tError: "));
		msg -> append (lua_tostring(instance, -1));
		lua_pop (instance, 1);
		throw invalid_argument (*msg);
		}

return errno;
}


