// =====================================================================================
// 
//       Filename:  vimrun.cc
// 
//    Description:  Source code for the multi language vim-gvim run program 
//
//          $Id: virun.cc,v 1.4 2010/03/14 16:52:43 mike Exp $
//          $Revision: 1.4 $
// 
//          Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//          Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>            
// 
//          This file is free software; as a special exception the author gives     
//          unlimited permission to copy and/or distribute it, with or without       
//          modifications, as long as this notice is preserved.                      
//
//          This program is distributed in the hope that it will be useful, but      
///          WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//           implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================
//
#include "vrun.h"
using 	namespace edn;
using 	namespace edm;
bool	edm::isXterm;




int main(int argc,char *argv[]){
Error<string> E;	
string	FileName;
string 	CmdLine;
unsigned int  mIndex;


            if (argc != 2) {
                E->Quit("Filename required!\n");
            }

			try {
				FileName = argv[1];
				Vrun R(FileName); 
				CmdLine = R->Getenv("TERM");
				CmdLine == "xterm" ? isXterm = true : isXterm = false;

				mIndex = R->Validity(FileName); 
				CmdLine.clear();
				CmdLine = R->ReadBuildConfig("cmdline.arg");  

			if(operator==("ON",CmdLine)) {

				E->Mesg("\nEnter arguments to command: ");
				getline(std::cin,CmdLine);
				}  
				R->RunName(mIndex,CmdLine);

			} catch (const FileError& e) {
				E->Mesg(e.what());
			} catch ( ... ) {
				E->Quit("unrecognized exception!");
			}


return 0;
}

