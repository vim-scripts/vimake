// =====================================================================================
// 
//       Filename:  vhelp.cc
// 
//    Description:  Display the hot keys used in the vim-gvim vimmake program 
//
//          $Id: vhelp.cc,v 1.4 2010/03/14 16:52:43 mike Exp $
//          $Revision: 1.4 $
// 
//          Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//          Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>            
// 
//          This file is free software; as a special exception the author gives     
//          unlimited permission to copy and/or distribute it, with or without       
//          modifications, as long as this notice is preserved.                      
//
//          This program is distributed in the hope that it will be useful, but      
//          WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//          implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================
//
#include "vmake.h"
using   namespace edn;
using   namespace edm;
bool    edm::isXterm;


int main(int argc,char *argv[]){
	Error <string>E;
	string  FileName;	
	string  CmdLine;
	ostringstream ostr;

		if (argc != 2)
				E->Quit("Filename required!");

		try {
			FileName = argv[1];
			Vkeys M(FileName);
			CmdLine = M->Getenv("TERM");
			CmdLine == "xterm" ? isXterm = true : isXterm = false;
			M->Validity(FileName);
                                
			isXterm == true ? 	ostr <<  "\n\t\e[1;37;44m  VIMAKE HOTKEYS  \e[0m\n" : 
								ostr <<  "\n\t  VIMAKE HOTKEYS\n";
			isXterm == true ? 	ostr << Blue : ostr << "\n\t";
								ostr << "<F1>"; 
			isXterm == true ? 	ostr << Off : ostr << "\t";
								ostr <<"\t\tReturn back from a Quickfix window."; 
			isXterm == true ? 	ostr << Blue : ostr << "\n\t";
								ostr << "<F2>"; 
			isXterm == true ? 	ostr << Off : ostr << "\t";
								ostr << "\t\tQuit does NOT save the current file. File contents unchanged.";
			isXterm == true ? 	ostr << Blue : ostr << "\n\t";
								ostr << "<F3>"; 
			isXterm == true ? 	ostr << Off : ostr << "\t";
								ostr << "\t\tSelect single or multi file builds. OFF single file build. ON multi file build.";
			isXterm == true ? 	ostr << Blue : ostr << "\n\t";
								ostr << "<F4>"; 
			isXterm == true ? 	ostr << Off : ostr << "\t";
								ostr << "\t\tOpen a Quickfix window.";
			isXterm == true ? 	ostr << Blue : ostr << "\n\t";
								ostr << "<F5>"; 
			isXterm == true ? 	ostr << Off : ostr << "\t";
								ostr << "\t\tStep down through errors in a Quickfix window.";
			isXterm == true ? 	ostr << Blue : ostr << "\n\t";
								ostr << "<F6>"; 
			isXterm == true ? 	ostr << Off : ostr << "\t";
								ostr << "\t\tStep back through errors in a Quickfix window.";
			isXterm == true ? 	ostr << Blue : ostr << "\n\t";
								ostr << "<F7>"; 
			isXterm == true ? 	ostr << Off : ostr << "\t";
								ostr << "\t\tClose the Quickfix window.";
			isXterm == true ? 	ostr << Blue : ostr << "\n\t";
								ostr << "<F8>";
			isXterm == true ? 	ostr << Off : ostr << "\t";
								ostr << "\t\tView current build selection. Does not perform a build with this key ON."; 
			isXterm == true ? 	ostr << Blue : ostr << "\n\t";
								ostr << "<F9>";
			isXterm == true ? 	ostr << Off : ostr << "\t";
								ostr << "\t\tSave(write) current contents to file.";
			isXterm == true ? 	ostr << Blue : ostr << "\n\t";
								ostr << "<F10>";
			isXterm == true ? 	ostr << Off : ostr << "\t";
								ostr << "\t\tBuild(make) single or multiple files.";
			isXterm == true ? 	ostr << Blue : ostr << "\n\t";
								ostr << "<F11>";
			isXterm == true ? 	ostr << Off : ostr << "\t";
								ostr << "\t\tRun(execute) current file with or without arguments.";
			isXterm == true ? 	ostr << Blue : ostr << "\n\t";
								ostr << "<F12>";
			isXterm == true ? 	ostr << Off : ostr << "\t";
								ostr << "\t\tDebug mode selects debugger on current file.";
			isXterm == true ? 	ostr << Blue : ostr << "\n\t";
								ostr << "<Ctrl+Up>";
			isXterm == true ? 	ostr << Off : ostr << "\t";
								ostr << "\tSelect build(make) options.";
			isXterm == true ? 	ostr << Blue : ostr << "\n\t";
								ostr << "<Ctrl+Down>";
			isXterm == true ? 	ostr << Off : ostr << "\t";
								ostr << "\tHot key menu.\n";
		
			cout << ostr.str();	
		} catch (const FileError& e) {
			E->Mesg(e.what());
		} catch ( ... ) {
			E->Quit("unrecognized exception");
			}

return(0);
}
