#ifndef __VMAKE__H
#define __VMAKE__H
// =====================================================================================
// 
//       Filename:  vmake.h
// 
//    Description:  Header File for the Vkeys class
// 
//          $Id: vmake.h,v 1.3 2009/12/18 19:55:24 mike Exp $
//          $Revision: 1.3 $
// 
//         Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//	 Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>           
//	                                                                          
//	 This file is free software; as a special exception the author gives      
//	 unlimited permission to copy and/or distribute it, with or without       
//	 modifications, as long as this notice is preserved.                      
//	                                                                          
//	 This program is distributed in the hope that it will be useful, but      
//	 WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// 
// =====================================================================================



//----------------------------------------------------------------------
//   	Header and Namespace declarations.
//----------------------------------------------------------------------
#include 	<iostream>
#include 	<fstream>
#include 	<sstream>
#include 	<string>
#include 	<list>
#include 	<map>
#include 	<memory>
#include 	<vector>
#include 	<algorithm>
#include 	<sys/stat.h>
#include 	<sys/wait.h>
#include 	<pwd.h>
#include 	<utime.h>
#include  	"utils.h"



namespace 	edn {

using 	std::cout;
using 	std::cerr;
using 	std::endl;
using 	std::ends; 	
using 	std::ifstream; 
using 	std::ofstream; 
using 	std::ios;
using 	std::string; 	
using 	std::list;
using 	std::vector;
using 	std::istringstream;
using 	std::ostringstream;
using 	std::stringstream;

}



namespace 	edm{
extern bool isXterm;	
using 	namespace edn;

				template <class Any>
				void Swap(Any &a,Any &b) {
					Any temp;
					temp = a;
					a = b;
					b = temp;
					}


//----------------------------------------------------------------------
// 		Offsets into a vector of strings
//----------------------------------------------------------------------
const 	unsigned HeaderFileList   = 0;
const 	unsigned SourceFileList   = 1;
const 	unsigned ObjectFileList   = 2;
const 	unsigned AssemblyFileList = 3;
const 	unsigned TemporaryObject  = 4;
const 	unsigned IncludeFileList  = 5;
const 	unsigned HeaderFileName   = 6;
const 	unsigned ObjectFileName   = 7;
const 	unsigned SourceFileName   = 8;
const 	unsigned TempFileExtent   = 9;

// =====================================================================================
//        Class:  Vkeys
//  Description:  A class of utility methods to  manage multi language assembly,compiling
//  			  and linking.
// =====================================================================================
	class Vkeys : public virtual Utils {  
		protected:
			string	_MainFileSrc;   	
			string	_MainFileObj;   	
			string	_MainFileExe;
			string  _MainFileHdr;
			string	_Options;		
			string	_Libraries;		
			string 	_BuildFile; 	
	   		string 	_LinkOne;
	   		string 	_LinkTwo;
	   		string 	_LinkThree;
			string::size_type _Index;
		public:
			Vkeys(std::string &str);
			virtual ~Vkeys() {};
			virtual string Bcompile(string &str);   
			virtual int BuildMainFile(const string &str);
			virtual int BuildMainFile(void);
  			virtual int Blink (string &str);
			virtual int Argcount();
			virtual int Makefile(string &str); 
			virtual bool CheckFileTimes(const string &st1,const string &st2); 
			Vkeys *operator->() { return this; };
	};
}
#endif

