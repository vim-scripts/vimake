// =====================================================================================
// 
//       Filename:  vimake.cc
// 
//    Description:  Source code for the multi language vim-gvim make program 
//
//        $Id: vimake.cc,v 1.5 2009/12/05 09:23:31 mike Exp $
//        $Revision: 1.5 $
// 
//         	Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//	 		Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>            
// 
//	 		This file is free software; as a special exception the author gives     
//	 		unlimited permission to copy and/or distribute it, with or without       
//	 		modifications, as long as this notice is preserved.                      
//
//	 		This program is distributed in the hope that it will be useful, but      
//	 		WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 		implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================
#include "vmake.h"
using 	namespace edn;
using 	namespace edm;
bool 	edm::isXterm;




int main(int argc,char *argv[]){
Error<string> E;	
string 	FileName;
string 	CmdLine;


			if (argc != 2) 
				E->Quit("Filename required!\n");
			
			try {	
				FileName = argv[1];
				Vkeys K(FileName);
				CmdLine = K->Getenv("TERM");
				CmdLine == "xterm" ? isXterm = true : isXterm = false;

				K->Validity(FileName);	
				CmdLine.clear();
				CmdLine = K->ReadBuildConfig("cmdline.arg"); 

			if (operator==("ON",CmdLine)) { 

				E->Mesg("Enter build<make> files: ");
				getline(std::cin,CmdLine);
			if (CmdLine.size() > 0) {
				K->BuildMainFile(CmdLine);
			} else {	
				K->BuildMainFile(); 
				}
			}else 
				K->BuildMainFile(); 

			} catch (const FileError& e) {
				E->Mesg(e.what());
			} catch ( ... ) {
				E->Quit("Unrecognized exception");
				}


return 0;
}
