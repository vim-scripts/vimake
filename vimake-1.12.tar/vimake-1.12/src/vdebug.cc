// =====================================================================================
// 
//       Filename:  vdebug.cc
// 
//    Description:  Source code for the Vimake (debugger package)
// 
//        $Id: vdebug.cc,v 1.3 2010/03/18 12:08:51 mike Exp $
//        $Revision: 1.3 $
// 
//         Author:  Mike Lear , mikeofthenight2003@yahoo.com
//	                                                                          
//	 	Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>            
//	                                                                          
//	 	This file is free software; as a special exception the author gives      
//	 	unlimited permission to copy and/or distribute it, with or without      
//	 	modifications, as long as this notice is preserved.                      
//	                                                                          
//	 	This program is distributed in the hope that it will be useful, but      
//	 	WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 	implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
//	                                                                         
// =====================================================================================

#include "vdebug.h"
namespace   edm {
using       namespace edn;


// =====================================================================================
//       Class:  	VIDBUG
//      Method:  	CONSTRUCTOR
// =====================================================================================
Vidbug::Vidbug(std::string &InMainFileName) {   
struct stat statbuf;
std::string::size_type idx;      	
std::string FileNameExt;				 


			_DisplayMode  = 0;
			_MainFileSrc = InMainFileName;
			_MainFileObj  = InMainFileName;
			_MainFileExe  = InMainFileName;
			idx = InMainFileName.rfind('.');

		if (idx == std::string::npos) { 
			throw FileIndexError(InMainFileName.c_str());

		} else {		

			FileNameExt.assign(_MainFileSrc,idx,_MainFileSrc.size());   
			_MainFileExe.erase (idx, FileNameExt.size ());		 
			_MainFileObj.replace(idx,FileNameExt.size(),".o");   
			}

		if (stat(_MainFileSrc.c_str(),&statbuf)<0){
			throw FileStatError(InMainFileName.c_str());
			}

}

// =====================================================================================
//       Class:  VIDBUG
//      Method:  VALIDITY
// Description:  Determine suitablity of the file type for use with debuggers.
// 		  NOTE:  File type with an index of five are included to allow the F12
// 		  		 key to be used with DDD for the bashdb and perldb debuggers.
// 		  		 This program only controls C/C++ AT&T and NASM assembler
// 		  		 debuggers.
// =====================================================================================
int Vidbug::Validity(const std::string& InFileName){
std::string FileExtent,FileName;
std::string::size_type index;

			FileName = InFileName; 
			index    = FileName.rfind('.');
			FileExtent.assign(FileName,index,FileName.size());
			index    = Getfilext(FileExtent);

		if ((index < 1) || (index > 5)) {
			throw FileUnknownError(FileName.c_str());
			}

return index;
}


// =====================================================================================
//       Class:  VIDBUG
//      Method:  GETFILEXT
// Description:  Map a file names extension to an integer. See Note in previous
// 				 function regarding perl and bash file extensions.
// =====================================================================================
int Vidbug::Getfilext(const std::string &Extension) {
std::map<const std::string,unsigned int> FileExtent;

		FileExtent[".c"]   = 1; 	FileExtent[".c++"] = 2; 
		FileExtent[".CPP"] = 2;		FileExtent[".cpp"] = 2; 
		FileExtent[".C"]   = 2; 	FileExtent[".cc"]  = 2;
		FileExtent[".cp"]  = 2; 	FileExtent[".cxx"] = 2; 
		FileExtent[".s"]   = 4;		FileExtent[".S"]   = 4; 
		FileExtent[".asm"] = 3;     FileExtent[".sh"]  = 5;
		FileExtent[".pl"]  = 5;		FileExtent[".pm"]  = 5;

		if (FileExtent.find(Extension) != FileExtent.end()) {
		return FileExtent[Extension];  
			} else {
		return 0; 
		}
}


// =====================================================================================
//       Class:  VIDBUG
//      Method:  DEBUGFILE
// Description:  Selects the designated debugger from a list of debuggers types situated
// 				 at $HOME/etc/debuggers. The function also selects the correct type of 
// 				 global debugger configuration file(usually .gdbinit) to suit either 
// 				 C/C++ AT&T or for the Nasm debugger (inteltype) configuration. This is 
// 				 achieved by use of the <F3> key during a <F12 Debug session>
// =====================================================================================
int	 Vidbug::DebugFile(const std::string& InDbugType){

struct stat StatBuf;
std::vector<std::string>Dvec(6);
std::string::size_type index,idx;
std::string CmdLine;


			Dvec[SrcDebugFile] = _MainFileSrc;
			Dvec[ExeDebugFile] = _MainFileExe;
			Dvec[MDebugger]    =  InDbugType;   

			index = Dvec[SrcDebugFile].rfind('.');
			Dvec[ExtentFile].assign(Dvec[SrcDebugFile],
					index,Dvec[SrcDebugFile].size());
			index = Getfilext(Dvec[ExtentFile]);
			Dvec[ExtentFile].erase(0,1);  
			std::ostringstream os;

 		 	Dvec[DbgInitAtt] = Getenv("HOME");
			(Dvec[DbgInitAtt]) += "/etc/gdbinit"; 

		if (stat(Dvec[DbgInitAtt].c_str(),&StatBuf)<0)
			throw FileStatError(Dvec[DbgInitAtt].c_str());
		
 			 Dvec[DbgInitIntel] = Getenv("HOME");
			(Dvec[DbgInitIntel]) += "/etc/inteltype";

		if (stat(Dvec[DbgInitIntel].c_str(),&StatBuf)<0)
			throw FileStatError(Dvec[DbgInitIntel].c_str());

		 	CmdLine = ReadBuildConfig("cmdline.arg");
        if (operator==("ON",CmdLine)) { 
			Dvec[DbgInitAtt].swap(Dvec[DbgInitIntel]);	
			}
			cout << nTab << "Config file: " << Dvec[DbgInitAtt].c_str() << " selected\n";
					
			//-----------------------------------------------------------------------
			//	Select global debugger configuration file.
			//	Idx set to 1 for gdb and gdbtui, set to 0 for others (ald,ddd,kdbg)
			//-----------------------------------------------------------------------
			Dvec[MDebugger][0] == 'g' ? idx = 1 : idx = 0;

			if (idx) {
				os  << Dvec[MDebugger] << " -q -x " << Dvec[DbgInitAtt] <<
				" " << Dvec[ExeDebugFile] << endl;
			} else {
				os << Dvec[MDebugger] << " " << Dvec[ExeDebugFile] << endl;
			}
			//-----------------------------------------------------------------------
			//	Debug only valid file types
			//-----------------------------------------------------------------------
			switch(index){
				case 1:
				case 2:
				case 3:
				case 4: 	os.str();
							break;
				default:	break;
				}
			
				   	if (Runcmd(os.str().c_str())<0) {
						throw RunTimeError(os.str());
						}

		
return 0; 			
}


// =====================================================================================
//       Class:  VIDBUG
//      Method:  READDEBUGGERS
// Description:  Open's the file $HOME/etc/debuggers from which a type of debugger or
// 				 Front end like Kdbg or DDD may be selected. This selection is then used
// 				 as the current debugger. If the list is empty (No debuggers listed) then
// 				 the menu is skipped and the default debugger usually Gdb is loaded.
// =====================================================================================
std::string Vidbug::ReadDebuggers(const std::string& InFileName){
std::string LocalFileName,TempString,FileTmpBuffer;
std::vector<std::string>::iterator itr;
typedef std::istream_iterator<std::string> str_input;
std::vector<std::string> dbvec;

			//---------------------------------------------------------------------------
			// 		Build path to /home/user/etc/debuggers 	 
			//		Open and read list of available debuggers and front ends.
			//---------------------------------------------------------------------------
			LocalFileName = InFileName;
 		 	TempString = Getenv("HOME");
			TempString.append("/etc/");
			LocalFileName.insert(0,TempString);
			std::ifstream fin(LocalFileName.c_str());   
		if (fin.fail()){
			throw  FileOpenError(InFileName.c_str());
			}
			copy(str_input(fin),str_input(),back_inserter(dbvec));

		if (!fin.eof()){
			fin.close();
			throw FileReadError(InFileName.c_str());
			}

			TempString.clear();
		for (itr=dbvec.begin();itr!=dbvec.end();++itr)
			TempString += *itr + " "; 

			std::istringstream ist(TempString);

			//--------------------------------------------------------------------------
			//		Return a space separated list of debuggers in FileTmpBuffer
			//---------------------------------------------------------------------------
		while (ist >> TempString) {
			Getenvpath(TempString.c_str());
			FileTmpBuffer += TempString + " ";
			}

		fin.close();


return FileTmpBuffer;  
}

} // namespace edm
