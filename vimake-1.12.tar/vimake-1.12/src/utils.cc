// =====================================================================================
// 
//       Filename:  utils.cc
// 
//    Description:  Utility Class for the Vim - Gvim Multi Lanuage Build Project.
// 
//          $Id: utils.cc,v 1.3 2009/10/21 17:25:27 mike Exp $
//          $Revision: 1.3 $
// 
//         	Author:  Mike Lear , mikeofthenight2003@yahoo.com
//	 		Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>            
//	                                                                          
//	 		This file is free software; as a special exception the author gives      
//	 		unlimited permission to copy and/or distribute it, with or without       
//	 		modifications, as long as this notice is preserved.                      
//	                                                                          
//	 		This program is distributed in the hope that it will be useful, but      
//	 		WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 		implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
//	                                                                          
// =====================================================================================



#include "utils.h"
extern char **environ;
namespace edm {
using namespace edn;


//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  VALIDITY ( Check for a valid filetype for building)
// Description:  Checks that the filename entered has a valid filename extension
// 				 and is of a suitable file type for building.
// 				 Index of 1,2,3 are valid for c,c++,gas(as) and nasm source files
// 				 all other filetypes are rejected.
//--------------------------------------------------------------------------------------
int Utils::Validity(const string& InFileName) {
	
string FileExtent;
string FileName;
string::size_type index;

			FileName = InFileName;
			index = FileName.rfind('.');
			FileExtent.assign(FileName,index,FileName.size());
			index = GetFileExt(FileExtent);
		if ((index < 1) || (index > 3)) {
			throw FileUnknownError(FileName.c_str());
			}

return index;
}


//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  READBUILDCONFIG
// Description:  Read the first line from the build options files which is placed at
// 				 $HOME/etc.  Each type of build consists of pair of files that
// 				 contain compile and link options. Each pair of files are identified
// 				 by the file extension currently being built. So that if a c++ build
// 				 is taking place then the files cc_options and cc_libraries would be
// 				 used. In a similar manner if a nasm program is called the the files
// 				 concerned would be asm_options and asm_libraries. Each pair of files
// 				 contain compile and link library options placed in them by the user. 
//--------------------------------------------------------------------------------------
string Utils::ReadBuildConfig(const string& InFileName) {

string FileTmpBuffer,LocalFileName,TempString;

			LocalFileName = InFileName;
 		 	TempString = Getenv("HOME");
			TempString += "/etc/";
			LocalFileName.insert(0,TempString);
			ifstream fin(LocalFileName.c_str(),ios::in);

		if (fin.fail()) {
			throw FileOpenError(InFileName.c_str());
			}
			getline (fin, FileTmpBuffer);
			fin.seekg(8,ios_base::beg);
			fin >> _DisplayMode;
		if (!fin.eof() && (fin.fail()||fin.bad())) {
			fin.clear();
			fin.close();
			}

		if (fin.eof()) {
			fin.clear();
			fin.close();
			}

		if (!fin.good()) {
			throw FileReadError(LocalFileName.c_str());
			}
return FileTmpBuffer;
}

//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  STRSTR (Search for word in a text file)
// Description:  Search for a given word in a file. The file is first copied as a series
// 				 of words into a vector of strings.  It is then sorted, a binary search 
// 				 returns bool true or false.
//--------------------------------------------------------------------------------------
bool Utils::Strstr(const string &InFileName,const string &SrchFileName) {
vector<string>::iterator itr;
typedef istream_iterator<string> str_input;
vector<string> vec;
string word;


			word = SrchFileName;
			ifstream fin(InFileName.c_str());

		if (fin.fail()) {
			throw FileOpenError(InFileName.c_str());
			}

			copy(str_input(fin),str_input(),back_inserter(vec));
			sort(vec.begin(),vec.end());

		if (!fin.eof()) {
			fin.close();
			throw FileReadError(InFileName.c_str());
		}
			fin.close();
			bool Find_Word = false;
			Find_Word = binary_search(vec.begin(),vec.end(),word);

return Find_Word;
}


//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  GETFILEXT ( Map a files extension) 
// Description:  Search a map for a valid filename extension. 
// 		 Input:  The ".ext" of the filename  to check
// 		Output:  Returns a positive integer if found.
// 				 or 0 if not in the map.
// 		  Note:	 filename extensions returning 4 are not used
// 		         in this particular program.
//--------------------------------------------------------------------------------------
int Utils::GetFileExt(const string &Extension) {
map<const string,unsigned int> FileExtent;


		FileExtent[".c"]   = 1;		FileExtent[".c++"] = 2;
		FileExtent[".CPP"] = 2;		FileExtent[".cpp"] = 2;
		FileExtent[".C"]   = 2; 	FileExtent[".cc"]  = 2;
		FileExtent[".cp"]  = 2; 	FileExtent[".cxx"] = 2;
		FileExtent[".s"]   = 3;		FileExtent[".S"]   = 3;
		FileExtent[".asm"] = 3; 	FileExtent[".h"]   = 5;
		FileExtent[".H"]   = 5; 	FileExtent[".hh"]  = 5;
		FileExtent[".inc"] = 6; 	FileExtent[".mac"] = 6;
		FileExtent[".pl"]  = 4; 	FileExtent[".py"]  = 4;
		FileExtent[".pm"]  = 4; 	FileExtent[".rb"]  = 4;
		FileExtent[".sh"]  = 4; 	FileExtent[".bash"]= 4;

		if (FileExtent.find(Extension) != FileExtent.end()) {
			return FileExtent[Extension];
		} else {
			return 0;
			}
}


//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  SREPLACE
// Description:  Search and replace a substring within a string.
// 		 Input:	 String to be searched,old sub string to remove,new substring to insert 	 
// 	   Returns:	 Bool true if search was successful. 
// 	   			 Bool false if search failed.
//--------------------------------------------------------------------------------------
bool Utils::Sreplace(string &str,const string &orig,const string &newstr) {
string::size_type idx;

			idx = str.find(orig);

		if (idx != string::npos) {
			str.replace(idx,orig.size(),newstr);
			return true;
			}
			return false;
}



//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  GETENV
// Description:  String version of the "C" getenv function, 
// 				 The returned strings in the environment list are of the form NAME=VALUE
// 				 This function throws an exception if the environment NAME is not found.
//--------------------------------------------------------------------------------------
string Utils::Getenv(const string &name) {
		auto_ptr<string>  envbuf(new string);
		auto_ptr<unsigned> count(new unsigned);
		auto_ptr<unsigned>   len(new unsigned);

			*len = name.length();
		for (*count = 0; environ[*count] != NULL; ++*count) {

		if ((name.compare(0,*len,environ[*count],0,*len) == 0) &&
            (environ[*count][*len] == '=')) {
            *envbuf += &environ[*count][*len+1];
			return(*envbuf); // env found
			}
		}
		throw FileEnvError(name.c_str());
}


//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  GETENVPATH
// Description:  This appends the input filename to the end of each path and
// 				 returns the path if found. If filename is not in any environment
// 				 path an exception is thrown. This normally occurs if you attempt
// 				 to run a file that has not yet been compiled or the file is non existant
// 				 or is not in the environment path of the user.
//--------------------------------------------------------------------------------------
string  Utils::Getenvpath(const string &fname) {
struct stat statbuf;
string path;

            path = Getenv("PATH");
         if (path.empty()) {
			throw FilePathError(fname.c_str());
            }

		while (Sreplace(path,":","/ "));
			istringstream instr(path);

        while (instr >> path) {
            path.append(fname);
        if (stat(path.c_str(),&statbuf)<0) {
			continue;
		} else {
			return(path.c_str());
			break;
			}
		}
		throw FileStatError(fname.c_str());
}


//--------------------------------------------------------------------------------------
//       Class:  UTILS
//      Method:  RUNCMD
// 		Description:  Executes a command in a child process.
// 		This function with some slight modifications is derived from:
// 		"ADVANCED PROGRAMMING IN THE UNIX ENVIRONMENT" by
//		Richard Stevens and Stephen A Rago.
//--------------------------------------------------------------------------------------
int Utils::Runcmd(const std::string& cmd) {
Error<string> E;	

			std::string Shell;
			std::auto_ptr<pid_t>   childpid(new pid_t);
			int       status = 0;
			struct    sigaction SaveInt,SaveQuit,Ignore;
			sigset_t  ChildMask,SaveMask;
			Shell =   Getenvpath("bash");		
            Ignore.sa_handler = SIG_IGN;
            sigemptyset(&Ignore.sa_mask);
            Ignore.sa_flags = 0;

        if (sigaction(SIGINT,&Ignore,&SaveInt)<0) {
			E->Quit("SIGINT Handler failed!\n");
            }
        if (sigaction(SIGQUIT,&Ignore,&SaveQuit)<0) {
			E->Quit("SIGQUIT handler failed!\n");
            }
            sigemptyset(&ChildMask);
            sigaddset(&ChildMask,SIGCHLD);

        if (sigprocmask(SIG_BLOCK,&ChildMask,&SaveMask)<0) {
			E->Quit("SIGNALMASK failed!\n");
            }

        if ((*childpid = fork())<0) {
            E->Quit("Fork or childpid failed!\n");
        } else if (*childpid == 0) {
            sigaction(SIGINT, &SaveInt, NULL);
            sigaction(SIGQUIT,&SaveQuit,NULL);
            sigprocmask(SIG_SETMASK,&SaveMask,NULL);
			
		//----------------------------------------------------------------------------	
		//			Child executes the command line string
		//----------------------------------------------------------------------------	
         execl(Shell.c_str(),Shell.c_str(),"-c",cmd.c_str(),(char *)0);
		 throw RunTimeError("Exec failed in Runcmd function!");
		
        } else {
        while (waitpid(*childpid,&status,0)<0)
        if (errno != EINTR) {
			E->Quit("Parent failed whilst waiting for child\n");
            break;
            }
        }
		//----------------------------------------------------------------------------	
		//			Restore the original signal handlers
		//----------------------------------------------------------------------------	
        if (sigaction(SIGINT,&SaveInt,NULL)<0) {
			E->Quit("Unable to restore SIGINT handler\n");
            }
        if (sigaction(SIGQUIT,&SaveInt,NULL)<0) {
			E->Quit("Unable to restore SIGQUIT handler!\n");
            }
        if (sigprocmask(SIG_SETMASK,&SaveMask,NULL)<0) {
			E->Quit("Unable to restore Sigprocmask!\n");
        }
		
return status;
}

} // edm namespace ends
