#ifndef __ERROR_H__
#define __ERROR_H__
// =====================================================================================
// 
//       Filename:  error.h
// 
//    Description:  Header File for the error class
// 
//       $Id: error.h,v 1.5 2009/11/13 10:48:04 mike Exp $
//       $Revision: 1.5 $
// 
//         Author:  Mike Lear  mikeofthenight2003@yahoo.com
//   Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>           
//                                                                            
//   This file is free software; as a special exception the author gives      
//   unlimited permission to copy and/or distribute it, with or without       
//   modifications, as long as this notice is preserved.                      
//                                                                            
//   This program is distributed in the hope that it will be useful, but      
//   WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//   implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// 
// =====================================================================================
//
#include <pwd.h>
#include <string>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <cstdarg>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <algorithm>
#include <unistd.h>


namespace edn {
	using std::cout;
	using std::cerr;
	using std::ends;
	using std::ios;
	using std::endl;
	using std::copy;
	using std::string;
	using std::ios_base;
	using std::ifstream;
	using std::ofstream;
	using std::ostream;
	using std::exception;
	using std::stringstream;
	using std::istringstream;
	using std::ostringstream;
	using std::istream_iterator;

//			Some Ansi Codes
inline ostream &TabRed(ostream &stream) { stream << "\n\t\e[31mError: \e[0m ";return stream;}
inline ostream &HiGreen(ostream &stream){ stream << "\n\t\e[1;32m";return stream;}
inline ostream &Black(ostream &stream)  { stream << "\n\t\e[30m";return stream;}
inline ostream &Red(ostream &stream)    { stream << "\n\t\e[31m";return stream;}
inline ostream &Green(ostream &stream)  { stream << "\n\t\e[32m";return stream;}
inline ostream &Yellow(ostream &stream) { stream << "\n\t\e[33m";return stream;}
inline ostream &Blue(ostream &stream)   { stream << "\n\t\e[34m";return stream;}
inline ostream &Magenta(ostream &stream){ stream << "\n\t\e[35m";return stream;}
inline ostream &Cyan(ostream &stream)   { stream << "\n\t\e[36m";return stream;}
inline ostream &White(ostream &stream)  { stream << "\n\t\e[37m";return stream;}
inline ostream &nTab(ostream &stream)   { stream << "\n\t"; return stream;}
inline ostream &Off(ostream &stream)    { stream << "\e[0m";return stream;}


}

namespace edm{
using namespace edn;

extern bool isXterm;


// Dual class template for a <string,int> or <int,string> ----------
template <typename T1,typename T2>
class Dual {
	private:	
		T1 a;
		T2 b;
	public:
		void Show(const T1 &inVal,const T2 &inVal1);
		Dual() {}
		~Dual() {}
		Dual *operator->() { return this; }
};


template<typename T1,typename T2>
void  Dual<T1,T2>::Show(const T1& inVal,const T2& inVal1) {
	 ostringstream ostr;
		a  = inVal;
		b = inVal1;
		isXterm == true ? ostr << Blue : ostr << "\n\t";
		isXterm == true ? ostr << a << Off : ostr << a;
		ostr <<  "\t\t" << b;
		cerr << ostr.str();
}

// Error Class Template --------------------------------------------		
template<typename T>
class Error {
		T a,b,c;
	public:
		Error();
		~Error(){};
		void Mesg(const T& inVal);
		void Mesg(const T& inVal,const T& inVal1);
		void Mesg(const T& inVal,const T& unVal1, const T& inVal2);
		void Quit(const T& inVal);
		void Quit(const T& inVal,const T& inVal1);
		void Quit(const T& inVal,const T& unVal1, const T& inVal2);
		Error *operator->() { return this; }
};

template <typename T> // template constructor
Error<T>::Error() { }

template <typename T>
void  Error<T>::Mesg(const T& inVal) {
	            a  = inVal;
				cerr << nTab <<  a;
}

template <typename T>
void  Error<T>::Mesg(const T& inVal,const T& inVal1) {
	            a  = inVal;
				b = inVal1;
				cerr << nTab <<  a << " " << b;
}

template <typename T>
void  Error<T>::Mesg(const T& inVal,const T& inVal1,const T& inVal2) {
	 ostringstream ostr;
				ostr << nTab << inVal << " " << inVal1 << " " << inVal2;
				cerr << ostr.str();
}

template <typename T>
void  Error<T>::Quit(const T& inVal) {
	 ostringstream ostr;
				isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
				a  = inVal;
				ostr << a;
				cerr <<  ostr.str();
				exit(1);
}


template <typename T>
void  Error<T>::Quit(const T& inVal,const T& inVal1) {
	 ostringstream ostr;
				isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
				a  = inVal;
				b = inVal1;
				ostr  <<  a << " " << b;
				cerr <<  ostr.str();
				exit(1);
}

template <typename T>
void  Error<T>::Quit(const T& inVal,const T& inVal1,const T& inVal2) {
	 ostringstream ostr;
				isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
				a  = inVal;
				b = inVal1;
				c = inVal2;
				ostr  <<  a << " " << b << " " << c;
				cerr <<  ostr.str();
				exit(1);
}


// Message Function Template ---------------------------------------
template<typename T1,typename T2,typename T3>
void Mesg(T1 a,T2 b,T3 c) {
		std::cout << "\t" << a << " " << b << " " << c << std::endl;
}

// Non Templated classes follow ------------------------------------
		
class FileError :  public exception {
	protected:
		std::string _File, _Mesg;
	public:
		FileError(const std::string& fileIn) : std::exception(), _File(fileIn) {}
		virtual ~FileError() throw() {}

		virtual const char* what() const throw() { return _Mesg.c_str(); }
		std::string getFileName() { return _File; }
};


class RunTimeError : public FileError {
	public:
		RunTimeError(const std::string& fileNameIn);
		virtual ~RunTimeError() throw() {}
};

class FileIndexError : public FileError {
	public:
		FileIndexError(const std::string& fileNameIn);
		virtual ~FileIndexError() throw() {}
};


class FileOpenError : public FileError {
	public:
		FileOpenError(const std::string& fileNameIn);
		virtual ~FileOpenError() throw() {}
};

class FileWriteError : public FileError {
	public:
		FileWriteError(const std::string& fileNameIn);
		virtual ~FileWriteError() throw() {}
};


class FileReadError : public FileError
{
	public:
		FileReadError(const std::string& fileNameIn);
		virtual ~FileReadError() throw() {}
};

class FileStatError : public FileError {
	public:
		FileStatError(const std::string& fileNameIn);
		virtual ~FileStatError() throw() {}
};

class FilePathError : public FileError {
	public:
		FilePathError(const std::string& fileNameIn);
		virtual ~FilePathError() throw() {}
};

class FileUnknownError : public FileError {
	public:
		FileUnknownError(const std::string& fileNameIn);
		virtual ~FileUnknownError() throw() {}
};

class FileEnvError : public FileError {
	public:
		FileEnvError(const std::string& fileNameIn);
		virtual ~FileEnvError() throw() {}
};

class BadFileName : public FileError {
	public:
		BadFileName(const std::string& fileNameIn);
		virtual ~BadFileName() throw() {}
};

} // namespace edm
#endif // __ERROR_H__
