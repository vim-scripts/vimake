// =====================================================================================
// 
//       Filename:  vmake.cc
// 
//    Description: 	Source code for the Linux Version of the Vim-Gvim Make Utility.
//					Methods for building, running and debugging	multi language programs. 					
//
//         $Id: vmake.cc,v 1.9 2009/12/18 12:08:51 mike Exp $
//         $Revision: 1.9 $
// 
//         	Author:  Mike Lear 
//	 		Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>   
//	                                                                          
//	 		This file is free software; as a special exception the author gives      
//	 		unlimited permission to copy and/or distribute it, with or without       
//	 		modifications, as long as this notice is preserved.                      
//	                                                                          
//	 		This program is distributed in the hope that it will be useful, but      
//	 		WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 		implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================
//
#include 	"vmake.h"
namespace 	edm {
extern bool isXterm;
using 		namespace edn;	


Vkeys::Vkeys(std::string &InMainFileName) {

			std::string::size_type idx;
			std::string FileNameExt;  


		   	_DisplayMode  = 0;
			_MainFileSrc = InMainFileName;
			_MainFileObj  = InMainFileName;
			_MainFileExe  = InMainFileName;
			_Index 		  = std::string::npos;
			_LinkOne        = "gcc -o ";	
			_LinkTwo        = "g++ -o ";
			_LinkThree      = "ld -o ";

 			idx 		  = InMainFileName.rfind('.');
			if ( _Index == idx )
		 	throw FileIndexError(InMainFileName.c_str());

			FileNameExt.assign(_MainFileSrc,idx,_MainFileSrc.size());
			_MainFileExe.erase (idx, FileNameExt.size ());
			_MainFileObj.replace(idx,FileNameExt.size(),".o");
}


// ---  FUNCTION ARGCOUNT (Static Counter) ---------------------------------------------
// 			   Static counter controls the  "Show build option".
// -------------------------------------------------------------------------------------
int Vkeys::Argcount() {
		static	int i = 0;			
				i++; 
return i;
}


// ---  FUNCTION BLINK (Build Link) ---------------------------------------------------
//  			Link methods for single  or multiple files
// -------------------------------------------------------------------------------------
int  Vkeys::Blink(string &InFileName) {
	
				ostringstream os;
				string FileExtent;
				const string Start("main");
				bool IsAtt	=	false;
				_Libraries	= 	"_libraries";
				_Index 		=	 InFileName.rfind('.');    

				FileExtent.assign(InFileName,_Index,InFileName.size());    
				_Index = GetFileExt(FileExtent);
				FileExtent.erase(0,1); 
				FileExtent+=_Libraries; 
	   	 		_Libraries = ReadBuildConfig(FileExtent); 

	switch(_Index) {

			case 1:		os << _LinkOne << _MainFileExe << " " << _BuildFile <<
						_MainFileObj << _Libraries << endl;
					 	cout << os.str();

					if (!_DisplayMode) {
					if (Runcmd(os.str().c_str())<0){
						throw RunTimeError(InFileName);
						}
					}
					break;

			case 2:		os << _LinkTwo << _MainFileExe << " " << _BuildFile <<
						 _MainFileObj << _Libraries; 
					 	cout << os.str().c_str() << endl;

					if (!_DisplayMode) {
					if (Runcmd(os.str().c_str())<0){
						throw RunTimeError(InFileName);
						}
					}
					break;

			case 3:     IsAtt = Strstr(InFileName,Start);
						IsAtt != false ? _Libraries = " -lc ",  os << _LinkOne  : os << _LinkThree;
						os << _MainFileExe << " " << _BuildFile << 
							  _MainFileObj << _Libraries << endl; 
						cout << os.str();

					if (!_DisplayMode) {
					if (Runcmd(os.str().c_str())>0){
						throw RunTimeError(InFileName);
						}
					}
					break;
		  default:    	throw RunTimeError(InFileName);
					break;
					}
return 0;	
}



// ---  FUNCTION BCOMPILE (Build Compile) ---------------------------------------------
//  		  Build methods for single or multi-language files
// -------------------------------------------------------------------------------------
string Vkeys::Bcompile(string &InFileName) { 
Error <string> E;	
					struct stat StatBuffer;
					ostringstream os,osob;
					string::size_type Index_1,Index_2; 
					string FileExtent,ObjectName,CheckForProg;
					string ProgramFile,Options_S,Options_A;
					const string Start("movl");
					bool IsAtt = false;

					_Options 	= "_options";
					_Index 		= InFileName.rfind('.');     
					ObjectName 	= InFileName;
					Index_2 	= Index_1 = 0; 

					FileExtent.assign(InFileName,_Index,InFileName.size());   
					ObjectName.replace(_Index,FileExtent.size(),".o");
					_Index = GetFileExt(FileExtent);
					FileExtent.erase(0,1); 
					FileExtent+=_Options; 
			//----------------------------------------------------------------------
			//  ReadBuildConfig - read the first line from a set of previously defined
			//  configurations.
			//----------------------------------------------------------------------
          	   	 _Options = ReadBuildConfig(FileExtent); 
				int count = Argcount();		

		if ((_DisplayMode)&&(count==1)) {
			if (isXterm) {
				E->Mesg("\n\t\e[34m","Current build configuration settings:","\e[0m\n");
			} else {
				cout << "\n\t" << "Current build configuration settings:\n";
				}
			}
		
	switch(_Index) {

		case 1:   	os << _Options << " " <<  InFileName; 
				 	cout << os.str() << endl;

				if (!_DisplayMode) {
				if (Runcmd(os.str().c_str())>0){
					throw RunTimeError(InFileName);
					}
				}
				break;
		case 2:   	os << _Options << " " <<  InFileName;  
				 	cout << os.str().c_str() << endl;

				if (!_DisplayMode) {
				if (Runcmd(os.str().c_str())>0){
					throw RunTimeError(InFileName);
					}
				}
				break;

		case 3: 	IsAtt = Strstr(InFileName,Start);
					Options_S = ReadBuildConfig("s_options");		
					Index_2 = _Options.find_first_of(" "); 
					CheckForProg = (_Options.substr(Index_1,Index_2-Index_1));
					ProgramFile = Getenvpath(CheckForProg.c_str());

				if (stat(ProgramFile.c_str(),&StatBuffer)<0)
					throw FileStatError(ProgramFile.c_str());

					Options_A = ReadBuildConfig("asm_options");	
					IsAtt = Strstr(InFileName,Start);
					IsAtt != false ? os << Options_S << " " << ObjectName : os << Options_A;
					os << " " << InFileName << endl;  
				 	cout << os.str();

				if (!_DisplayMode) {
				 if (Runcmd(os.str().c_str())<0){
					throw RunTimeError(InFileName);
					}
				}
				break;
	default: 	break;
	}
return InFileName;	
}


// ---  FUNCTION BUILDMAINFILE (Multiple Files) ----------------------------------------
//  		    Build Main Source File along with additional program files
// -------------------------------------------------------------------------------------
int  Vkeys::BuildMainFile(const std::string &InCommandLine) {
	
struct stat MainFileBuffer,MainObjBuffer,MainExeBuffer;
				vector<time_t>fileTime;
				vector<time_t>::iterator tm;
				std::string TempString;
				std::string::size_type idx;
				unsigned status = 0;

			//----------------------------------------------------------------------
			// 		Initialize modification times to zero for any file not yet created.
			//----------------------------------------------------------------------
			if (stat(_MainFileSrc.c_str(),&MainFileBuffer)<0)
				{ MainFileBuffer.st_mtime=0; }
			if (stat(_MainFileObj.c_str(),&MainObjBuffer)<0)
				{ MainObjBuffer.st_mtime=0; }
			if (stat(_MainFileExe.c_str(),&MainExeBuffer)<0)
				{ MainExeBuffer.st_mtime=0; }

			//----------------------------------------------------------------------		
			//  	Obtain the list of filenames from a project file
			//----------------------------------------------------------------------  	
                idx = InCommandLine.find(".prj");
            if (idx != std::string::npos) {	    
				_BuildFile = Getenv("PWD");
				_BuildFile += "/" + InCommandLine;
                std::ifstream fin(_BuildFile.c_str(),std::ios::in);
            if (fin.fail()) {
                throw FileOpenError(InCommandLine.c_str());
                }
                getline(fin,TempString);
                fin.clear();
                fin.close();
                _BuildFile=TempString;
             if (!fin.good()) {
				throw FileReadError(InCommandLine.c_str());
				}
            } else 
			//----------------------------------------------------------------------		
			//		Obtain the list of filenames from build prompt
			//----------------------------------------------------------------------		
			{	_BuildFile=InCommandLine;  }

            	 status=Makefile(_BuildFile);  //  Call Makefile  

			//----------------------------------------------------------------------
			// 		Compile main file according to modification time
			//----------------------------------------------------------------------
				fileTime.push_back(MainFileBuffer.st_mtime);
				fileTime.push_back(MainObjBuffer.st_mtime);
				tm = max_element(fileTime.begin(),fileTime.end());


			if ( *tm  > MainExeBuffer.st_mtime ) {
				Bcompile(_MainFileSrc);               
				status=1;
				}
		   if (_DisplayMode){   
				fileTime.push_back(MainFileBuffer.st_mtime);
				fileTime.push_back(MainObjBuffer.st_mtime);
				tm = min_element(fileTime.begin(),fileTime.end());
			if ( *tm  < MainExeBuffer.st_mtime ) {
				 Bcompile(_MainFileSrc);               
				status =1;
			   }
			}

			while (fileTime.size() > 0) { 
				fileTime.erase(fileTime.begin());
				}
			//----------------------------------------------------------------------
			//  	Link according to file modification times
			//----------------------------------------------------------------------
			
                std::stringstream obstr(_BuildFile);
            while (obstr >>  TempString) {
                stat(TempString.c_str(),&MainObjBuffer);
				fileTime.push_back(MainObjBuffer.st_mtime);
				}
				tm = max_element(fileTime.begin(),fileTime.end());

			if ( *tm  > MainExeBuffer.st_mtime ) {
				status=1;
				}
			if (status) {
                Blink(_MainFileSrc);
			} else {
				cout << nTab << _MainFileExe << " is up to date!\n";
				}
return status;
}


// ---  FUNCTION  BUILDMAINFILE (Single File) ------------------------------------------
//  			Build the Main Source File entered on the command line.
// -------------------------------------------------------------------------------------
int  Vkeys::BuildMainFile(void) {
	
				struct stat MainFileBuffer,MainObjBuffer,MainExeBuffer;
				vector<time_t>fileTime;
				vector<time_t>::iterator tm;
				unsigned status = 0;
			
			//----------------------------------------------------------------------
			// 		Initialize modification times to zero for any file not yet created.
			//----------------------------------------------------------------------
			if (stat(_MainFileSrc.c_str(),&MainFileBuffer)<0)
				{ MainFileBuffer.st_mtime=0; }
			if (stat(_MainFileObj.c_str(),&MainObjBuffer)<0)
				{ MainObjBuffer.st_mtime=0;  }
			if (stat(_MainFileExe.c_str(),&MainExeBuffer)<0)
				{ MainExeBuffer.st_mtime=0;  }


			//----------------------------------------------------------------------
			// 		Compile main file according to modification time
			//----------------------------------------------------------------------
				fileTime.push_back(MainFileBuffer.st_mtime);
				fileTime.push_back(MainObjBuffer.st_mtime);
				tm = max_element(fileTime.begin(),fileTime.end());
			if ( *tm  > MainExeBuffer.st_mtime ) {
				Bcompile(_MainFileSrc);     
				status=1;
				}
			if (_DisplayMode) {
				fileTime.push_back(MainFileBuffer.st_mtime);
				fileTime.push_back(MainObjBuffer.st_mtime);
				tm = min_element(fileTime.begin(),fileTime.end());
			if ( *tm  < MainExeBuffer.st_mtime ) {
				Bcompile(_MainFileSrc);     
				status=1;
				}
			}
			//----------------------------------------------------------------------
			//		Check and link accordingly
			//----------------------------------------------------------------------
			if (status) {
				Blink(_MainFileSrc);
			} else { 
				cout << nTab << _MainFileExe << " is up to date !\n";
			}

return status;
}


// ---  FUNCTION  CHECKFILETIMES -------------------------------------------------------
//                Checks the  file access and modification times. 
// 				  Returns bool true  if times are updated.
// -------------------------------------------------------------------------------------
bool Vkeys::CheckFileTimes(const string &HeaderName,const string &SourceName) { 
	
			struct stat HeaderBuffer,SourceBuffer; 
			struct utimbuf timebuf;
			bool status = false;
			string FileNameExt;				 


			//----------------------------------------------------------------------
			// If the header or source file does not exist --- quit
			//----------------------------------------------------------------------
			if (stat(HeaderName.c_str(),&HeaderBuffer)<0) {
				throw FileStatError(HeaderName.c_str());
				}

			if (stat(SourceName.c_str(),&SourceBuffer)<0) {
				throw FileStatError(SourceName.c_str());
				}


			//----------------------------------------------------------------------
			// If any Header file has a more recent time than it's corresponding 
			// source file. Change source file time and set status. To prevent multi
			// builds where the header file time would constantly appear more recent.
			//----------------------------------------------------------------------
			if (HeaderBuffer.st_mtime > SourceBuffer.st_mtime) {  
				timebuf.actime  = HeaderBuffer.st_atime;  
				timebuf.modtime = HeaderBuffer.st_mtime;  

			if (utime(SourceName.c_str(),&timebuf)<0) {
				cout << nTab << "Unable to change times on " << SourceName.c_str();
				exit(1);
				}
				status = true;  
			}  								
return status;
}


// ---  FUNCTION  MAKEFILE ------------------------------------------------------------
// Description:  Makefile parses the command line, builds a vector of strings grouped by each
// 				 file extension type. Determines which files require assembling by examining
// 				 file times. After any assembling has been performed, returns the link status
// 				 along with a list of object filenames for linking.
// -------------------------------------------------------------------------------------
int Vkeys::Makefile(string &InCommandLine) {
	
				vector<time_t>fileTime;
				vector<time_t>::iterator tm;
				stringstream IoStream; 
				vector <string>Vec(10); 
				list<string> List; 
				list<string>::iterator itr;
				string::size_type idx; 
				string FileNameExt,TempHdrString;
				struct stat HeaderBuffer,ObjectBuffer,SourceBuffer; 
				struct stat MainFileBuffer,MainObjBuffer,MainExeBuffer; 
				bool result = false;
				int status 	= 0;

				//----------------------------------------------------------------------
				// 		Initialize modification times to zero for any file not yet created.
				//----------------------------------------------------------------------
			if  (stat(_MainFileSrc.c_str(),&MainFileBuffer)<0)
				{ MainFileBuffer.st_mtime=0;}   
			if  (stat(_MainFileObj.c_str(),&MainObjBuffer)<0)
				{ MainObjBuffer.st_mtime=0;}  
			if 	(stat(_MainFileExe.c_str(),&MainExeBuffer)<0)
				{ MainExeBuffer.st_mtime=0;}  

				//----------------------------------------------------------------------
				//		For each file on command line. If we can't stat -- exit.
				//		If we have no file suffix -- exit. If ok, map to an int.
				//----------------------------------------------------------------------
					stringstream InputStream(InCommandLine);
		  while (InputStream >> Vec[TemporaryObject]) {
			if 	(stat(Vec[TemporaryObject].c_str(),&ObjectBuffer)<0)
				{ throw FileStatError(Vec[TemporaryObject].c_str()); }
				idx=Vec[TemporaryObject].find('.');					   
			if	(idx == std::string::npos) 
				{ throw FileIndexError(Vec[TemporaryObject].c_str()); }
				Vec[TempFileExtent].assign(Vec[TemporaryObject],	  
				idx,Vec[TemporaryObject].size());
				idx=GetFileExt(Vec[TempFileExtent]);				  


				//----------------------------------------------------------------------
				//		Sort files by type where  [1,2] are c/c++.  [3] is assembly.
				//		[5] is headers.  [6] is include and macro files.
				//		Create a string of object filenames.
				//----------------------------------------------------------------------
			switch(idx) {  
			case 1:  
			case 2: 	Vec[SourceFileList]+=Vec[TemporaryObject]+" ";  
						Vec[TemporaryObject].replace(Vec[TemporaryObject].size()-
						Vec[TempFileExtent].size(),
						Vec[TempFileExtent].size(),".o");
						Vec[ObjectFileList]+=Vec[TemporaryObject]+" "; 
						break;
			case 3: 	Vec[AssemblyFileList]+=Vec[TemporaryObject]+" ";  
						Vec[TemporaryObject].replace(Vec[TemporaryObject].size()-
						Vec[TempFileExtent].size(),
						Vec[TempFileExtent].size(),".o");
						Vec[ObjectFileList]+=Vec[TemporaryObject]+" ";  
						break;
			case 5: 	Vec[HeaderFileList]+=Vec[TemporaryObject]+" ";
						break;
			case 6: 	Vec[IncludeFileList]+=Vec[TemporaryObject]+" ";
						break;
			default:	throw BadFileName(Vec[TemporaryObject].c_str());		
					 	break;
						}
				} 	// End of command line parser

			


				//----------------------------------------------------------------------
				//		InCommandLine contains a complete list of object filenames for linking.
				//----------------------------------------------------------------------
				//
						InCommandLine=Vec[ObjectFileList];
			
				//----------------------------------------------------------------------
				// 		First pass deals with the header(.H)  and C/C++ files. 
				// 		Pass two is for Nasm/Gnu[gas] and  include/macro files.
				//----------------------------------------------------------------------
			for (int count=0; count<2; count++) { 	
			
				//----------------------------------------------------------------------
				// 		IF THERE ARE NO HEADER FILES BUT THERE ARE SOURCE FILES 
				//----------------------------------------------------------------------
			if ((Vec[HeaderFileList].size() == 0)&&(Vec[SourceFileList].size() > 0)) { 

				//----------------------------------------------------------------------
				//		Build streams of object and source files. Place in List source
				//		files that require building.
				//----------------------------------------------------------------------
						stringstream ObjectStream(Vec[ObjectFileList]); 
						stringstream SourceStream(Vec[SourceFileList]); 
			while 	(( ObjectStream >> Vec[ObjectFileName]) &&
					 ( SourceStream >> Vec[SourceFileName])) {   
			if (stat(Vec[SourceFileName].c_str(),&SourceBuffer)<0)  
						{ SourceBuffer.st_mtime = 0; }  
			if (stat(Vec[ObjectFileName].c_str(),&ObjectBuffer)<0)   
						{ ObjectBuffer.st_mtime = 0; }                      
			if (SourceBuffer.st_mtime > ObjectBuffer.st_mtime) { 
						List.insert(List.end(),Vec[SourceFileName]);       
						status = 1;
						}
				//----------------------------------------------------------------------
				//      If DisplayMode show configuration
				//----------------------------------------------------------------------
			if (_DisplayMode) { 
			if (SourceBuffer.st_mtime < ObjectBuffer.st_mtime) { 
						List.insert(List.end(),Vec[SourceFileName]);       
						status = 1;
						}
						fileTime.push_back(MainFileBuffer.st_mtime);
						fileTime.push_back(MainObjBuffer.st_mtime);
						tm = min_element(fileTime.begin(),fileTime.end());
			if ( *tm  < MainExeBuffer.st_mtime ) {
						status=1;
						}
					} 
				} 

						fileTime.push_back(MainFileBuffer.st_mtime);
						fileTime.push_back(MainObjBuffer.st_mtime);
						tm = max_element(fileTime.begin(),fileTime.end());
			if ( *tm  > MainExeBuffer.st_mtime ) {
						status=1;
						} 
			else if (MainExeBuffer.st_mtime > ObjectBuffer.st_mtime) {
						status=0;		 
						}
				} else  
				//----------------------------------------------------------------------
				// 		IF THERE ARE BOTH HEADER FILES AND  SOURCE FILES 
				//----------------------------------------------------------------------
			if ((Vec[HeaderFileList].size() > 0)&&(Vec[SourceFileList].size() > 0)) { 

						stringstream HeaderStream(Vec[HeaderFileList]);  
			while (HeaderStream >> Vec[HeaderFileName]) {    
						stringstream ObjectStream(Vec[ObjectFileList]); 
						stringstream SourceStream(Vec[SourceFileList]); 
			while 	((ObjectStream >> Vec[ObjectFileName])&&
					(SourceStream	>> Vec[SourceFileName])) { 
			if (stat(Vec[HeaderFileName].c_str(),&HeaderBuffer)<0)
						{ HeaderBuffer.st_mtime = 0; }
			if (stat(Vec[ObjectFileName].c_str(),&ObjectBuffer)<0) 
						{ ObjectBuffer.st_mtime = 0; }
			if (stat(Vec[SourceFileName].c_str(),&SourceBuffer)<0) 
						{ SourceBuffer.st_mtime = 0; }

				//----------------------------------------------------------------------
				//		Search each source file for corresponding header or include file
				//----------------------------------------------------------------------
						TempHdrString = Vec[HeaderFileName]; 
						TempHdrString = "\""+TempHdrString+"\"";
						result = Strstr(Vec[SourceFileName],TempHdrString);    
			if (result) {		
						status = CheckFileTimes(Vec[HeaderFileName],Vec[SourceFileName]); 

			if (_DisplayMode) {
						List.insert(List.end(),Vec[SourceFileName]); 
						status = 1;
			if (( SourceBuffer.st_mtime < ObjectBuffer.st_mtime) ||
				( HeaderBuffer.st_mtime < SourceBuffer.st_mtime)) { 
							List.insert(List.end(),Vec[SourceFileName]);  
							status = 1;	
							} 
						} 
				//----------------------------------------------------------------------
				//		If found and if status place file in list for building
				//----------------------------------------------------------------------
			if (status) { 			
						List.insert(List.end(),Vec[SourceFileName]); 
						status = 1;
						}

			if (( SourceBuffer.st_mtime > ObjectBuffer.st_mtime) ||
				( HeaderBuffer.st_mtime > SourceBuffer.st_mtime)) { 
							List.insert(List.end(),Vec[SourceFileName]);  
							status = 1;	
							} 
						} 
					}  					
				}             		 						  
			}  else 
				//----------------------------------------------------------------------
				// 		IF THERE ARE HEADER FILES BUT NO SOURCE FILES 
				//----------------------------------------------------------------------
		   	if ((Vec[HeaderFileList].size() > 0)&&(Vec[SourceFileList].size() == 0)) { 

						vector<time_t>fileTime;
						vector<time_t>::iterator tm;
				//----------------------------------------------------------------------
				//		No source files so use the main filename
				//----------------------------------------------------------------------
						Vec[SourceFileName] = _MainFileSrc.c_str();  
						stringstream HeaderStream(Vec[HeaderFileList]);

			while (HeaderStream >> Vec[HeaderFileName]) {  

						TempHdrString = Vec[HeaderFileName]; 
						TempHdrString = "\""+TempHdrString+"\"";

				//----------------------------------------------------------------------
				// 		Search each header/include file against the main source file 
				//----------------------------------------------------------------------
						result = Strstr(_MainFileSrc.c_str(),TempHdrString);   

			if (result) {    	
			 			status = CheckFileTimes(Vec[HeaderFileName],Vec[SourceFileName]); 
			if (status ) { 									  
						status = 1;	
			} else { 
			if (_DisplayMode) { 
						fileTime.push_back(MainFileBuffer.st_mtime);
						fileTime.push_back(MainObjBuffer.st_mtime);
						tm = min_element(fileTime.begin(),fileTime.end());
			if ( *tm  < MainExeBuffer.st_mtime || MainObjBuffer.st_mtime == 0) {
							status = 1;	
							}
						} 
						fileTime.push_back(MainFileBuffer.st_mtime);
						fileTime.push_back(MainObjBuffer.st_mtime);
						tm = max_element(fileTime.begin(),fileTime.end());
			if ( *tm  > MainExeBuffer.st_mtime || MainObjBuffer.st_mtime == 0) {
						status = 1;	
						}
					} 	
				} 		
			} 		

			} 		//  	END OF IF-ELSE-LOOPS

						Vec[SourceFileList].swap(Vec[AssemblyFileList]); 
						Vec[HeaderFileList].swap(Vec[IncludeFileList]);

			}		//		End of FOR LOOP	

							List.sort();            
							List.unique();		   
				
			for (itr=List.begin();itr!=List.end();++itr) { 
				Bcompile(*itr);
				status = 1;
				}

return status;		 		
} 

}  // namespace edm
