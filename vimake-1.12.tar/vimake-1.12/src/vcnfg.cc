// =====================================================================================
// 
//       Filename:  vcnfg.cc
// 
//    Description:  Source code to change the Make(build) configuration during a
//    				Vim - Gvim session. (part of the vimake package)
// 
//         $Id: vcnfg.cc,v 1.4 2010/03/18 12:08:51 mike Exp $
//         $Revision: 1.4 $
// 
//         Author:  Mike Lear, mikeofthenight2003@yahoo.com
//	                                                                          
//	 Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>            
//	                                                                          
//	 This file is free software; as a special exception the author gives      
//	 unlimited permission to copy and/or distribute it, with or without       
//	 modifications, as long as this notice is preserved.                      
//	                                                                          
//	 This program is distributed in the hope that it will be useful, but      
//	 WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//	 
// =====================================================================================
#include "vcnfg.h"
namespace edm {
using       namespace edn;

std::string Viconfig::GetViPath(const char* InFileName) {
Error <string> E;
struct passwd *pw;
std::string FileExtent;
std::string::size_type index;

		if (!(pw = getpwuid(getuid())))
			E->Quit("Unable to obtain user's home directory.\n");
	
			ViMakePath = InFileName;
		if (!ViMakePath.size()) E->Quit("Bad command\n");
			index = ViMakePath.rfind('.');
			FileExtent.assign(ViMakePath,index+1,ViMakePath.size());
			ViMakePath =  pw->pw_dir;
			ViMakePath += "/etc/" + FileExtent;

return ViMakePath;
}



// =====================================================================================
//       Class:   VICONFIG
//      Method:   GETSETCFG ( Get and Set build configuration)
//				  Create a menu allowing the user to choose a configuration
// =====================================================================================
int Viconfig::GetSetCfg(std::string& InFileName) {
Error <string>E;	
struct stat statbuf;

			_Libraries.insert(0,InFileName);
			_Options.insert(0,InFileName);
		//------------------------------------------------------------------------------		
		//	Change build options by selecting options from the options and library
		//	files situated at $HOME/etc
		//------------------------------------------------------------------------------		
		if (stat(_Libraries.c_str(), &statbuf)<0) 
			E->Quit("Not a vimake configuration file!\n");
		if (stat(_Options.c_str(),   &statbuf)<0)
			E->Quit("Not a vimake configuration file!\n");

		cout << nTab << "COMPILER-ASSEMBLER OPTIONS\n";
	  		MapToFile(_Options);
		cout << nTab << "LINK OPTIONS\n";
 			MapToFile(_Libraries);

return 0;
}


// =====================================================================================
//       Class:   VICONFIG
//      Method:   MapToFile  (Modify the position of configuration in a file using a Map)
// =====================================================================================
void Viconfig::MapToFile(std::string& InFileName) {
Error <string>E;	
extern bool isXterm;
std::string InFileLine,FirstMapLine,SecondMapLine;
std::map<int,std::string> vimap;             
std::map<int,std::string>::iterator itr;
unsigned int Selected = 0;
unsigned int Position = 0;
std::ifstream fin;
std::ofstream fout; 
std::string FirstLine,Last,Result;
std::ostringstream ostr;

			//----------------------------------------------------------------------
			//  Option menu for Vim or Gvim 
			//----------------------------------------------------------------------
		if (isXterm == true) { 
			FirstLine="\e[34mWhere option 1 is NO CHANGE\e[0m\n";
		} else {  
			FirstLine="Where option 1 is NO CHANGE\n"; 
			}

				fin.open(InFileName.c_str(), std::ios_base::in);
		if (!fin.is_open())	E->Quit("Unable to open ",InFileName.c_str()," for reading.\n");

			//----------------------------------------------------------------------
			//  Copy configuration file into a map, save first line of map.
			//----------------------------------------------------------------------
		while (getline(fin, InFileLine, '\n')) 						
			vimap.insert(std::pair<int,std::string>(++Position,InFileLine)); 
			itr = vimap.begin();
			FirstMapLine += itr->second; 								 
			cout << nTab << "Valid options are [ 1 - " << vimap.size()
				 <<	" ] " << FirstLine.c_str() << endl;

		for (itr = vimap.begin(); itr != vimap.end(); ++itr){
			isXterm == true ? ostr << Blue << " [" << itr->first << "]\t" << Off : 
							  ostr <<  "\t [" << itr->first << "]\t";
							  ostr << itr->second.c_str();
			if (isXterm == false) ostr << endl;				  
							  }
			cout << ostr.str() << endl;
			cout << "\n\tEnter no: ";

		if (!std::cin.good()) 
			E->Quit("input stream in a bad state\n");

  		while (true){
				std::cin >> Position;

			//----------------------------------------------------------------------
			//  Locate index and set iterator
			//----------------------------------------------------------------------
  		if (std::cin.good()){   
				itr = vimap.find(Position);
				break;

  		} else if 
				(std::cin.eof()){  		
				break; 

  		} else {  						      
				std::cin.clear();   	
				std::string badtoken; 	
				std::cin >> badtoken; 
				E->Quit("Bad input encountered: ",badtoken.c_str());
				}
		}
		//----------------------------------------------------------------------
		//  Use index to save the line selected in the map.
		//  At this point 2 lines from the map have been saved.
		//----------------------------------------------------------------------
		if (itr != vimap.end()) { 
				SecondMapLine += itr->second; 
				Selected += itr->first;
		} else {
				E->Quit("Invalid selection!\n");
		}

		//----------------------------------------------------------------------
		//  Erase the selected line in the map, also erase line 1 from the map.
		//  Swap the two saved lines over (strings FirtsMapLine,SecondMapLine)
		//  then insert these two lines back into the map in the erased positions.
		//  Finally write the modified map back to the configuration file.
		//----------------------------------------------------------------------
			vimap.erase(1); 			 		
			vimap.erase(Selected);       		    
			FirstMapLine.swap(SecondMapLine); 	
			vimap.insert(std::pair<int,std::string>(1,FirstMapLine)); 
			vimap.insert(std::pair<int,std::string>(Selected,SecondMapLine)); 
			fout.open(InFileName.c_str(), std::ios_base::out|std::ios_base::trunc);

		if (!fout.is_open())
			E->Quit("Unable to open ",InFileName.c_str()," for writing.\n");

		for (itr = vimap.begin(); itr != vimap.end(); ++itr) {
			fout  << itr->second << std::endl; 
			}
			fout.close();
		cout << nTab << "+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+";
		if (isXterm == true) { 
			cout << HiGreen << "Selected:   " << Off <<  FirstMapLine;
			cout << Red     << "Deselected: " << Off <<  SecondMapLine;
		} else {
			cout <<  "\n\tDeselected: "  <<  SecondMapLine;
			cout <<  "\n\tSelected:   "  <<  FirstMapLine;
			}
		cout << nTab << "+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+\n";
}

} // namespace ends

