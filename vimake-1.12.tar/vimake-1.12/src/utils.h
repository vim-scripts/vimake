#ifndef __UTILS__H
#define __UTILS__H
// =====================================================================================
// 
//       Filename:  utils.h
// 
//    Description:  Header File for the Utilities class
// 
//       $Id: utils.h,v 1.5 2009/10/21 17:25:05 mike Exp $
//       $Revision: 1.5 $
// 
//         Author:  Mike Lear  mikeofthenight2003@yahoo.com
//   Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>           
//                                                                            
//   This file is free software; as a special exception the author gives      
//   unlimited permission to copy and/or distribute it, with or without       
//   modifications, as long as this notice is preserved.                      
//                                                                            
//   This program is distributed in the hope that it will be useful, but      
//   WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//   implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// 
// =====================================================================================
//
#include 	<iostream>
#include 	<string>
#include 	<sstream>
#include 	<algorithm>
#include 	<fstream>
#include 	<memory>
#include 	<vector>
#include 	<map>
#include 	<sys/wait.h>
#include 	<sys/stat.h>
#include 	<signal.h>
#include 	<errno.h> 
#include 	<fcntl.h>
#include 	"error.h"

namespace 	edn {
using 	std::cout;        
using 	std::cerr;
using 	std::endl;
using 	std::ends;        
using 	std::ifstream;    
using 	std::ofstream;    
using 	std::ios;
using 	std::ios_base;
using 	std::string;      
using 	std::istringstream; 
using 	std::ostringstream; 
using 	std::stringstream;  
using 	std::auto_ptr;
using 	std::copy;
using 	std::map;
using 	std::sort;
using 	std::vector;
}


namespace 	edm {
using 	namespace edn;

	class Utils {
		protected:
			int    		_DisplayMode;
		public:
			Utils(){};	
			virtual	 ~Utils() {};
			virtual bool 	Sreplace(string &str,const string &orig,const string &newstr);
			virtual bool 	Strstr(const string &InFileName,const string &SrchFileName);
			virtual string 	Getenv(const string &name);
			virtual string 	Getenvpath(const string &fname);
			virtual string 	ReadBuildConfig(const string &str);
			virtual int 	Validity(const string& str);
			virtual int 	GetFileExt(const string &ext);
			virtual int 	Runcmd(const string& cmd);
	};

}
#endif
