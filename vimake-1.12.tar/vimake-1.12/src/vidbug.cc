//======================================================================================
//   
//   		Filename:  vidbug.cc
//       Description:  Source code for the multi language vim-gvim vimake program 
//
//           $Id: vidbug.cc,v 1.3 2010/03/11 19:55:24 mike Exp $
//           $Revision: 1.3 $
//
//	 Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>            
//	                                                                          
//	 This file is free software; as a special exception the author gives      
//	 unlimited permission to copy and/or distribute it, with or without       
//	 modifications, as long as this notice is preserved.                      
//	                                                                          
//	 This program is distributed in the hope that it will be useful, but      
//	 WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//	 
//======================================================================================
#include "vdebug.h"
using   namespace edn;
using   namespace edm;
bool    edm::isXterm;



int main(int argc,char *argv[]){
Error <string>E;
Dual<int,string> IS;
std::string FileName,DebugFileType;
std::string CmdLine;
std::vector<std::string>Mdebug(4);
std::vector<std::string>::iterator itr;
std::string::size_type index;
int DB = 1;



            if (argc != 2) {
				E->Quit("Filename required!");
				}


			try {
				FileName = argv[1];
				Vidbug D(FileName); 
				CmdLine = D->Getenv("TERM");
				CmdLine == "xterm" ? isXterm = true : isXterm = false;


		 		D->Validity(FileName); 
				DebugFileType = D->ReadDebuggers("debuggers");
			if (DebugFileType.empty()){
				E->Quit("No debuggers found!\n");
				}

				index = count(DebugFileType.begin(),DebugFileType.end(),' ');
			if (index != 1){
				std::istringstream ist(DebugFileType);
				std::ostringstream ost;
				E->Mesg("\n\tNOTE:  Only front end debuggers [ ddd - kdbg ] or similar, are supported in gvim.");
				isXterm == true ? ost << Blue << "Select Debugger" : ost << "\n\t" << "Select Debugger";
				E->Mesg(ost.str());
			while (ist >> DebugFileType) {
				Mdebug.push_back(DebugFileType);
				IS->Show(DB++,DebugFileType.c_str());  
				}

				DebugFileType.clear();
				E->Mesg("\n\t\b\bEnter No: ");
				std::cin >> DB;

			for (itr=Mdebug.begin();itr!=Mdebug.end();++itr,--DB)
			if  (DB == -3)  DebugFileType += *itr; 
				}
			if  (DebugFileType.empty()){ 
				E->Quit("Bad selection.\n");
				return(1);
				}

				D->DebugFile(DebugFileType);
			} catch (const FileError& e) {
				E->Mesg(e.what());
			} catch ( ... ) {
				E->Quit("Unrecognized exception");
				}


return 0;
}
