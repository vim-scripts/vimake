#ifndef __FDUMP__H
#define __FDUMP__H
// =====================================================================================
// 
//       Filename:  fdump.h
// 
//    Description:  Header File for the fdump class 
// 
//			$Id: fdump.h,v 1.1.1.1 2010/10/16 09:10:51 mike Exp $
//          $Revision: 1.1.1.1 $
// 
//         Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//   Copyright (C) 2006-10 Mike Lear <mikeofthenight2003@yahoo.com>           
//                                                                            
//   This file is free software; as a special exception the author gives      
//   unlimited permission to copy and/or distribute it, with or without       
//   modifications, as long as this notice is preserved.                      
//                                                                            
//   This program is distributed in the hope that it will be useful, but      
//   WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//   implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// 
// =====================================================================================
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <new>
#include <memory>
#include <string>
#include <sys/stat.h>
#include <stdexcept>
#include "autosprintf.h"

namespace edn {
using	std::ios_base;	
using   std::cout;
using   std::cerr;
using   std::endl;
using	std::string;
using	std::bad_alloc;
using 	std::ifstream;
using 	std::ostream;
using	std::auto_ptr;
using 	std::invalid_argument;
using 	std::runtime_error;
using 	gnu::autosprintf;

const unsigned int Bsize  = 32768;   // 32k buffer size



				class Fdump {
					protected:
						char 			*buf;           // pointer to buffer
						unsigned int	mSize;          // file size
						string			mfileName;      // file name 
					public:
						Fdump(const string &str)        throw (invalid_argument); 
						virtual char* setBuffer()       throw (bad_alloc);
						virtual void  dumpFile(int opt) throw(invalid_argument,runtime_error);
						virtual void  display(unsigned char *buf,int bytestoget,int opt );
						virtual ~Fdump() {};
						Fdump *operator->()             { return this; };
						};



} // namespace ends
#endif
