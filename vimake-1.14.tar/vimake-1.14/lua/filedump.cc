// =====================================================================================
// 
//       Filename:  filedump.cc 
//        
//    Description:  Ascii-Hex-Octal file dump using gnu::autosprintf
// 
//			To build:  vi filedump.cc  <F3> ON then press <F10>
//			Enter build arguments: fdump.h fdump.cc <Enter>
//
//			or: g++ -Wall -O2  fdump.cc filedump.cc -o filedump -lasprintf
//
//          $Id: filedump.cc,v 1.1.1.1 2010/10/16 09:10:51 mike Exp $
//          $Revision: 1.1.1.1 $
// 
//         Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//   Copyright (C) 2006-10 Mike Lear <mikeofthenight2003@yahoo.com>           
//                                                                            
//   This file is free software; as a special exception the author gives      
//   unlimited permission to copy and/or distribute it, with or without       
//   modifications, as long as this notice is preserved.                      
//                                                                            
//   This program is distributed in the hope that it will be useful, but      
//
//   WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//   implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// 
// =====================================================================================
#define ver "vimake-1.14"
#include "fdump.h"
using namespace edn;



int main (int argc, char *argv[]) {


			try {

			if (argc != 3) {
				const auto_ptr < string >  error (new string("\n\tUsage:  filedump [ -o | -x ] filename.ext\n"));
				throw (invalid_argument(error -> c_str() ));
				}
			   	const auto_ptr < string > filename (new string (argv[argc - 1]));
		  		const auto_ptr < string > option   (new string (argv[argc - 2]));
  					  auto_ptr < int >    opt      (new int);

			if ( option -> find ("-o") != string::npos ) {
	  			*opt = 1;
				} else

			if ( option -> find ("-x") != string::npos ) {
		  		*opt = 2;
				} else {

			  	*option = "\n\tError: bad option argument entered!\n";
		  		throw (invalid_argument(*option));
				}


				Fdump   Fd ( filename -> c_str());
						Fd -> setBuffer();
						Fd -> dumpFile( *opt );


   				} catch(const invalid_argument& e){
					cerr << e.what() << endl;
				exit (1);

				} catch (const runtime_error& e){
					cerr << e.what() << endl;
				exit (1);

				} catch (...) {
					cerr << "\n\tUndetermined exception occurred!" << endl;
				exit (1);
				}


    return (0);
  }
