------------ THIS SCRIPT IS BASED ON THE XD.LUA SCRIPT FROM LUA-5.4.1
--
-- 		usage:      lua  xdump.lua [ -o | -x ] filename
--
--  				or using the c++ program luadump.cc 
--
--             		luadump [ -o | -x ] filename 
--
--				 Dumps filename in ascii and hex or octal
--
-- 		When called by luadump  returns filesize
--
------------ THIS SCRIPT IS BASED ON THE XD.LUA SCRIPT FROM LUA-5.4.1



local fsize


function xdump(option,filename)


local fh 	 = assert(io.open(filename, "rb")) 				 -- open file in read only and binary
	  fsize  = assert(fh:seek("end"))  		   				 -- seek to end of file eof() [get filesize] 
local offset = assert(fh:seek("set"))  		   				 -- seek [back to start of file]

while filename do						

		local s = fh:read(16) 								 -- Read 16 bytes at a time
		if s==nil then return end							 -- until eof is reached.


 	if option=="-x" then 
		io.write(string.format("%08x  ",offset)) 			 -- display file offset
		string.gsub(s,"(.)",function(c) 
		io.write(string.format("%02x ",string.byte(c))) end) -- display 16 hex characters
	elseif option=='-o' then
		io.write(string.format("%08x  ",offset)) 			 -- display file offset
		string.gsub(s,"(.)",function(c) 
		io.write(string.format("%03o ",string.byte(c))) end) -- display 16 octal characters
	else    
		io.write(string.format("\n\tError: Bad option argument [ %s ] entered!\n",arg[1])) 
		fsize = 0;
		return 
	end
	    io.write(string.rep(" ",3*(16-string.len(s))))
		io.write(" ",string.gsub(s,"%c","."),"\n")  		 -- display 16 ascii text characters
	 	offset=offset+16			  						 -- next 16 bytes		
end
		fh:close()					   						 -- close the file	
end


assert(arg[2]~=nil,"usage: lua xdump.lua [ -o | -x ] file")   -- usage

			xdump(arg[1],arg[2]);                             -- call the function 
			return fsize                                      
