#ifndef __UTILS__H
#define __UTILS__H
// =====================================================================================
// 
//       Filename:  utils.h
// 
//    Description:  Header File for the Utilities class
// 
//       $Id: utils.h,v 1.6 2010/10/24 12:52:01 mike Exp $
//       $Revision: 1.6 $
// 
//         Author:  Mike Lear  mikeofthenight2003@yahoo.com
//   Copyright (C) 2006-10 Mike Lear <mikeofthenight2003@yahoo.com>           
//                                                                            
//   This file is free software; as a special exception the author gives      
//   unlimited permission to copy and/or distribute it, with or without       
//   modifications, as long as this notice is preserved.                      
//                                                                            
//   This program is distributed in the hope that it will be useful, but      
//   WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//   implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// 
// =====================================================================================
//
//
#include 	<iostream>
#include 	<string>
#include 	<bitset>
#include 	<sstream>
#include 	<algorithm>
#include 	<fstream>
#include 	<memory>
#include 	<vector>
#include 	<map>
#include 	<sys/wait.h>
#include 	<sys/stat.h>
#include 	<signal.h>
#include 	<errno.h> 
#include 	<fcntl.h>
#include 	<cctype>
#include 	"error.h"

namespace 	edn {
using 	std::cout;        
using 	std::cerr;
using 	std::endl;
using 	std::ends;        
using 	std::ifstream;    
using 	std::ofstream;    
using 	std::ios;
using 	std::ios_base;
using 	std::string;      
using 	std::istringstream; 
using 	std::ostringstream; 
using 	std::stringstream;  
using 	std::auto_ptr;
using 	std::copy;
using 	std::map;
using 	std::hex;
using 	std::dec;
using 	std::sort;
using 	std::vector;
using   std::boolalpha;
using   std::bitset;	
}


namespace 	edm {
using 	namespace edn;

			enum FunKeys { 
							F1, F2, F3,  F4,  F5,  F6, F7,
							F8, F9, F10, F11, F12, Keys
						 };

			enum LinkOpt {
							L1, L2, L3,  L4,  L5,  L6, L7, Link
						 };

			template <class InIter>  // display contents of a container
				void Showit(const char *msg,InIter start, InIter end){
					InIter itr;
					std::cout << msg;
					for (itr = start; itr != end; ++itr)
						std::cout << *itr << " ";
						std::cout << std::endl;
				}

			

	class Utils  {
		protected:
			int    		_DisplayMode;
			int			_Length;
			int			_FileLen;
			string		_Version;
		public:
			Utils(){};	
				virtual	 ~Utils() {};
				virtual bool Sreplace(string &str,const string &orig,const string &newstr);
				virtual bool Strstri(const string &InFileName,const string &SrchFileName);
				virtual bool Strstr (const string &InFileName,const string &SrchFileName);
				virtual long Strstr (const string &InFile);
				virtual int get_version();
				virtual void ResetBit();
				virtual auto_ptr < string > Getenv(const string &name);
				virtual auto_ptr < string >	Getenvpath(const string &fname);
				virtual auto_ptr < string > UpdateCmdLine (const string& InCmdArgs);
				virtual auto_ptr < string >	ReadBuildConfig(const string &str);
				virtual int Validity(const string& str);
				virtual int GetFileExt(const string &ext);
				virtual int Runcmd(const string& cmd);
		};


}
#endif
