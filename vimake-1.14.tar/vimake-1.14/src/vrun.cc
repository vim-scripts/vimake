// =====================================================================================
// 
//       Filename:  vrun.cc
// 
//    Description:  Run finished programs in a vim or gvim session
// 
//         $Id: vrun.cc,v 1.3 2010/10/27 18:50:36 mike Exp $
//         $Revision: 1.3 $
// 
//         Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//		   Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>            
//	                                                                          
//		   This file is free software; as a special exception the author gives      
//	 	   unlimited permission to copy and/or distribute it, with or without       
//		   modifications, as long as this notice is preserved.                      
//	                                                                          
//	 	   This program is distributed in the hope that it will be useful, but      
//	 	   WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	  	  implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================


#include "vrun.h"
extern char **environ;
namespace edm {
using namespace edn;


//--------------------------------------------------------------------------------------
//       Class:  VRUN
//      Method:  CONSTRUCTOR
// Description:  Parameter Initialization
//--------------------------------------------------------------------------------------
Vrun::Vrun(std::string &InMainFileName) {   

std::string::size_type idx;      	
std::string FileNameExt;				 

				_DisplayMode  = 0;
				_MainFileSrc = InMainFileName;
				_MainFileExe  = InMainFileName;
				idx 		  = InMainFileName.rfind('.');

			if (idx == std::string::npos) { 
				throw FileIndexError(InMainFileName);

			} else {		
				FileNameExt.assign(_MainFileSrc,idx,_MainFileSrc.size());   
				_MainFileExe.erase (idx, FileNameExt.size ());		 
				} 
}


//--------------------------------------------------------------------------------------
//       Class:  VRUN
//      Method:  GETINTERPRETER
// Description:  Maps source file extensions to the relevent Interpreter.
// 				 These are perl,python,ruby and bash
// 				 Attempts to run a script with the interpreter not installed 
// 				 will display:  
// 				 bin/bash (name of interpreter) command not found.
//--------------------------------------------------------------------------------------
/// auto_ptr < string >  Vrun::GetInterpreter(const string &Extension) {
string   Vrun::GetInterpreter(const string &Extension) {

 		map < string,string > FileExtent ;
				FileExtent[".pl"  ]  = "perl ";
				FileExtent[".py"  ]  = "python ";
				FileExtent[".rb"  ]  = "ruby ";
				FileExtent[".sh"  ]  = "bash "; 
				FileExtent[".bash"]	 = "bash ";
				FileExtent[".lua" ]	 = "lua ";
				FileExtent[".bin" ]	 = "lua ";


		if (FileExtent.find(Extension) != FileExtent.end()) {
				return FileExtent[Extension];
		} else {
				throw FileUnknownError("Bad interpreter");
				}
}



//--------------------------------------------------------------------------------------
//       Class:  VRUN
//      Method:  VALIDITY
// Description:  This version of Validity allows the running of the normal
// 				 vimake c,c++ and assembly programs. Also includes a feature
// 				 which allows lua,perl,python,ruby and bash scripts to be run
// 				 prior to them being made executable.
//--------------------------------------------------------------------------------------
int Vrun::Validity(const string& InFileName) {

string 		FileExtent;
string 		FileName;
string::size_type index;

				FileName = InFileName;
				index 	 = FileName.rfind('.');
				FileExtent.assign(FileName,++index,FileName.size());
				index 	 = GetFileExt(FileExtent);
        switch (index) {
			case 1:         // return only known file extension types.
			case 2:         // throw an error for all others.
			case 3:
			case 4:     
			case 6:    	break;
			default:    throw FileUnknownError(FileName.c_str());
						break;
			}


return index;
}


//--------------------------------------------------------------------------------------
//       Class:  VRUN
//      Method:  RUNNAME
// Description:  Runs the finished program or script
//--------------------------------------------------------------------------------------
int  Vrun::RunName(unsigned int Ext ,const std::string& InFileName="") {
      
struct		stat StatBuffer;
auto_ptr <string> TempString (Getenv("PWD"));
string		RunFileName;
string		FileExtent;
ostringstream 	os; 														
string::size_type 	index;


					//----------------------------------------------------------------------
					//  		Case 1,2,3 are for C,C++,Assemby.  
					//  		Case 4 is for Perl,Python,Ruby and Bash
					//  		Case 6 is for Lua
					//----------------------------------------------------------------------
		switch (Ext) {
			case 1:
			case 2:
			case 3:		RunFileName  = _MainFileExe;
						TempString -> append ("/");
						RunFileName.insert(0,*TempString);

					if (stat(RunFileName.c_str(),&StatBuffer)<0) {
					throw FileStatError(_MainFileExe.c_str());
					}
					break;
			case 4:		RunFileName  = _MainFileSrc;			
						index = RunFileName.rfind('.');
						FileExtent.assign(RunFileName,index,RunFileName.size());
						FileExtent = GetInterpreter(FileExtent);
						os << FileExtent;
						TempString -> append ("/");
						RunFileName.insert(0,*TempString);

				if (stat(RunFileName.c_str(),&StatBuffer)<0) {
					throw FileStatError(_MainFileSrc.c_str());
					}
					break;

			case 6:		RunFileName  = _MainFileExe;				// first check for a bin file
						RunFileName.append(".bin");             	// if so then use it
					if (stat(RunFileName.c_str(),&StatBuffer)<0) 	// otherwise
						RunFileName = _MainFileSrc;					// use the lua script to run
						index = RunFileName.rfind('.');
						FileExtent.assign(RunFileName,index,RunFileName.size());
						FileExtent = GetInterpreter(FileExtent);
						os << FileExtent;
						TempString -> append ("/");							// append path to script
						RunFileName.insert(0,*TempString);
					if (stat(RunFileName.c_str(),&StatBuffer)<0) {	// confirm path-file is ok
						throw FileStatError(_MainFileSrc.c_str());
						}
						break;

			default:	break;
			}

						_CmdLine = InFileName;												
						os << RunFileName << " " << _CmdLine << std::ends;
					if (Runcmd(os.str().c_str())<0){
						throw RunTimeError(InFileName);
						} 
return 0;
}


} // namespace edm
