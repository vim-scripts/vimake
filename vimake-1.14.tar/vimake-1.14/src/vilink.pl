# -* perl path line above auto-generated *-
use warnings;
use strict;
############################################################################
#                                                                          #
# Copyright (C) 2006 Mike Lear <mikeofthenight2003@yahoo.com>              #
#                                                                          #
#		$Id: vilink.pl,v 1.1.1.1 2010/10/16 09:11:17 mike Exp $                                                               #
#                                                                          #
# This file is free software; as a special exception the author gives      #
# unlimited permission to copy and/or distribute it, with or without       #
# modifications, as long as this notice is preserved.                      #
#                                                                          #
# This program is distributed in the hope that it will be useful, but      #
# WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   #
# implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. #
#                                                                          #
############################################################################

my ($ccoption)  = "cc_options";
my ($cclibrary) = "cc_libraries";
my ($etcdir) = "/etc";
my ($homedir) = (getpwuid($<))[7];
my $linkdir = $homedir.$etcdir;
my @optionnames = 
	("c++_options","cxx_options","cpp_options","cp_options","CPP_options","C_options");
my @librarynames = 
	("c++_libraries","cxx_libraries","cpp_libraries","cp_libraries","CPP_libraries","C_libraries");

		chdir($linkdir) || die "Can't cd to $linkdir:$!\n";
		foreach  my $name(@optionnames){
			symlink($ccoption,$name) or die "Cannot create symlink to $ccoption\n".
				"Soft links in \e[31m$linkdir\e[0m possibly already installed!\n";
			}
	     foreach  my $name(@librarynames){
			symlink($cclibrary,$name) or die "Cannot create symlink to $cclibrary\n";
			}
		symlink("s_options","S_options") or die "Cannot create symlink to s_options\n";
		symlink("s_libraries","S_libraries") or die "Cannot symlink to s_libraries\n";
		print"Soft links have been installed in \e[31m$linkdir\e[0m subdirectory.\n";
	
