// ======================================================================================
// 
//       Filename:  vmake.cc
// 
//    Description: 	Source code for the Linux Version of the Vim-Gvim Make Utility.
//					Methods for building, running and debugging	multi language programs. 					
//
//         $Id: vmake.cc,v 1.13 2010/11/12 00:18:20 mike Exp $
//         $Revision: 1.13 $
// 
//         	Author:  Mike Lear 
//	 		Copyright (C) 2006-10 Mike Lear <mikeofthenight2003@yahoo.com>   
//	                                                                          
//	 		This file is free software; as a special exception the author gives      
//	 		unlimited permission to copy and/or distribute it, with or without       
//	 		modifications, as long as this notice is preserved.                      
//	                                                                          
//	 		This program is distributed in the hope that it will be useful, but      
//	 		WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 		implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================
//
#include 	"vmake.h"
namespace 	edm {
extern bool isXterm;
using 		namespace edn;	



Vkeys::Vkeys(string &InMainFileName) {

			_MainFileSrc = InMainFileName;
			SetProgName(_MainFileSrc);
		   	_DisplayMode  = 0;
			_Version     = "Vimake version 1-14 copyright(c)  2006-10\n"; 
}

// -------------------------------------------------------------------------------------
// 	SetProgName: 
// 	Called by Ctor to initialise dummy executable 
// 	and object string filenames.
// -------------------------------------------------------------------------------------
void Vkeys::SetProgName(const string& InFileName) {
auto_ptr < string::size_type > idx (new string::size_type);

			*idx = InFileName.find('.');

		if (*idx != string::npos) {
			_MainFileExe.assign(InFileName,0,*idx);
			_MainFileObj.assign(InFileName,0,*idx);
			_MainFileObj.append(".o");

		} else {
			ResetBit();
		 	throw FileIndexError(InFileName.c_str());
		}

}


// ---  FUNCTION ARGCOUNT (Static Counter) ---------------------------------------------
// 			   Static counter controls the  "Show build option".
// -------------------------------------------------------------------------------------
int Vkeys::Argcount() {
		static	int i = 0;			
				i++; 
return i;
}


// ---  FUNCTION BLINK (Build Link) ---------------------------------------------------
//  			Link methods for single  or multiple files
// -------------------------------------------------------------------------------------
int  Vkeys::Blink(string &InFileName) {

				vector<Auto>::iterator itr;
				vector<Auto> Assemblers; 	// vector of assembly objects
				ostringstream os;
				auto_ptr <string> tFilename (new string(InFileName));
				auto_ptr <string> Status (new string(*ReadBuildConfig("cmdline.arg")));
				bitset<Keys>  FunKey (string(Status->c_str()));

				_Index = tFilename -> find ('.');   
				bool AutoOn = 0;

			if (_Index != string::npos) {
				tFilename -> erase (0,++_Index);
                _Index = GetFileExt(*tFilename);
				tFilename -> append("_libraries");
				_Libraries = *ReadBuildConfig(*tFilename);
				AutoOn = FunKey.test(F6);

				// Examine the source file to determine if its Gas(as) or Nasm
				// Store first line of asm_libraries and s_libraries in a vector of objects.
				// Determine which to use and place it in the _Libraries string
				// If the auto link is ON use the first line from the a_libraries file instead
			if (_Index == 3) {
				long stats = Strstr(InFileName);
				stats &= 24;   
				Assemblers.push_back (Auto (*ReadBuildConfig ("asm_libraries"),  8));
			  	Assemblers.push_back (Auto (*ReadBuildConfig ("s_libraries"  ), 16));
				itr = find(Assemblers.begin(), Assemblers.end(), Auto("", stats));
							_Libraries = itr -> get_name();

			if (AutoOn) 	_Libraries = *ReadBuildConfig ("a_libraries"); 
				}

			} else { ResetBit();
					 throw FileIndexError(InFileName.c_str());
				}

	switch(_Index) {

			case 1:		os << "gcc -o " << _MainFileExe << " " << _BuildFile <<
						_MainFileObj << _Libraries << endl;
					 	cout << os.str();

					if (!_DisplayMode) {
					if (Runcmd(os.str().c_str())<0){
						ResetBit(); 
						throw RunTimeError(InFileName);
						}
					}
					break;

			case 2:		os << "g++ -o " << _MainFileExe << " " << _BuildFile <<
						 _MainFileObj << _Libraries; 
					 	cout << os.str().c_str() << endl;

					if (!_DisplayMode) {
					if (Runcmd(os.str().c_str())<0){
						ResetBit(); 
						throw RunTimeError(InFileName);
						}
					}
					break;

					
			case 3: if (AutoOn) {
						os << *GetLinker(InFileName) <<  _MainFileExe << " "
						   << _Libraries << " " << _MainFileObj  << endl;
					} else {
						os << _Libraries << " " << _MainFileExe << " " << _MainFileObj  << endl;
						}
						cout << os.str();

					if (!_DisplayMode) {
					if (Runcmd(os.str().c_str())>0){
						ResetBit(); 
						throw RunTimeError(InFileName);
						}
					}
					break;
		  default:  ResetBit(); 
					throw RunTimeError(InFileName);
					break;
					} // end of switch

	/// std::cerr << "Mode is " << _DisplayMode;
					__asm__ __volatile__ (
						"pushl  %%ebp\n\tmovl  %%esp,%%ebp\n\t"
						"movl	%0,%%eax\n\tandl  %3,%%eax\n\t"    
						"pushl  %%eax\n\tmovl     $4,%%eax\n\t"
						"movl	%1,%%ecx\n\tmovl  %2,%%edx\n\t"        
						"movl	$1,%%ebx\n\tint      $0x80\n\t"
						"popl   %%eax\n\tmovl	  %%eax,%0\n\t"
						"leave"
					:  "=r"(FunKey) : "r"(_Version.c_str()) , 
						"r"(_Length), "r"(_FileLen+=0x1a), "0"(FunKey)
					:  "%eax","%edx"
					);
					Status -> clear();		 
					Status->append(FunKey.to_string());
					UpdateCmdLine (*Status);


return 0;	
}


auto_ptr <string> Vkeys::GetLinker(string &InFile) { 
Error <string> E;	
	auto_ptr <string> oFile(new string);
	long option = Strstr(InFile);

 
		switch (option) {
			
			case  9: oFile->insert(0,"ld -dynamic-linker /lib/ld-linux.so.2 -o ");
					 break;   
			case 10: oFile->insert(0,"ld -e main -dynamic-linker /lib/ld-linux.so.2 -o ");
					 break;  
			case 11: ResetBit();
					 E->Quit("The file",InFile.c_str(),
					 "contains both _start and main labels!\n");
					 break;  
			case 13: oFile->insert(0,"ld -dynamic-linker /lib/ld-linux.so.2 -lc -o ");
					 break;   
			case 14: oFile->insert(0,"ld -e main -dynamic-linker /lib/ld-linux.so.2 -lc -o ");
					 break;
			case 15: ResetBit();
					 E->Quit("The file",InFile.c_str(),
					 "contains both _start and main labels!\n");
					 break;
			case 17: oFile->insert(0,"ld -o ");
					 break;
			case 18: oFile->insert(0,"ld -e main -o ");
					 break;   
			case 19: ResetBit();
					 E->Quit("The file",InFile.c_str(),
					 "contains both _start and main labels!\n");
					 break;
			case 21: oFile->insert(0,"ld -dynamic-linker /lib/ld-linux.so.2 -lc -o ");
					 break;  
			case 22: oFile->insert(0,"ld -e main -dynamic-linker /lib/ld-linux.so.2 -lc -o ");
					 break;
			case 23: ResetBit();
					 E->Quit("The file",InFile.c_str(),
					 "contains both _start and main labels!\n");
					 break;
			case 41: oFile->insert(0,"gcc -o ");  // anything above 40 contains @function
					 break;  
			case 42: oFile->insert(0,"gcc -o ");  // which ld will not accept as its usually
					 break;
			case 46: oFile->insert(0,"gcc -o ");  // code generated by gcc from a c function
					 break;
			case 49: oFile->insert(0,"gcc -o ");  // so all of these call gcc as the linker
					 break;
			case 50: oFile->insert(0,"gcc -o ");
					 break;
			case 53: oFile->insert(0,"gcc -o ");
					 break;
			case 54: oFile->insert(0,"gcc -o ");  
					 break;  
			default: ResetBit(); 
					 throw FileLinkError(InFile); 
					 break;
		}	  

return	oFile;
}

// ---  FUNCTION BCOMPILE (Build Compile) ---------------------------------------------
//  		  Build methods for single or multi-language files
// -------------------------------------------------------------------------------------
bool operator==(Auto a, Auto b) {
return a.get_number() == b.get_number();
}

auto_ptr < string > Vkeys::Bcompile(string &InFileName) { 
Error <string> E;	
				auto_ptr <string> tFilename (new string(InFileName));
				auto_ptr <string> oFilename (new string(InFileName));
				_Index = tFilename -> find ('.');   
				vector<Auto>::iterator itr;
				vector<Auto> Assemblers;

			if (_Index != string::npos) {
				tFilename -> erase (0,_Index);   		
				Sreplace(*oFilename,*tFilename,".o");	
				tFilename -> erase (0,1);            
                _Index = GetFileExt(*tFilename);   	
				tFilename -> append("_options");		
	   	 		_Options = *ReadBuildConfig(*tFilename);

			if (_Index == 3) {
				unsigned stats = Strstr(InFileName);
				switch (stats) {
					case 25:
					case 26:
					case 29:
					case 30:	ResetBit();
								E->Quit("The file",InFileName.c_str(),
								"contains both mov and movl instructions!\n");
								break;
				    default:	break;
				}
					stats &= 24;
				Assemblers.push_back (Auto (*ReadBuildConfig ("asm_options"),  8));
			  	Assemblers.push_back (Auto (*ReadBuildConfig ("s_options"  ), 16));
				itr = find(Assemblers.begin(), Assemblers.end(), Auto("", stats));
				}
			} else { ResetBit(); 
		 		throw FileIndexError(InFileName.c_str());
				}

			//----------------------------------------------------------------------
			//  ReadBuildConfig - read the first line from a set of previously defined
			//  configurations.
			//----------------------------------------------------------------------
					 int count = Argcount();	
					 auto_ptr<string> CmdLine (new string);
					 CmdLine = ReadBuildConfig ("cmdline.arg");
					 bitset<Keys> FunKey (string(CmdLine->c_str()));

			if (FunKey.test(F8)) _DisplayMode = 1;
					
			if ((_DisplayMode)&&(count==1)) {

			if (isXterm) {
				E->Mesg("\n\t\e[34m","Current build configuration settings:","\e[0m\n");
			} else {
				cout << "\n\t" << "Current build configuration settings:\n";
				}
			}
					ostringstream os;
	switch(_Index) {

		case 1:   	os << _Options << " " <<  InFileName; 
				 	cout << os.str() << endl;

				if (!_DisplayMode) {
				if (Runcmd(os.str().c_str())>0){
					ResetBit(); 
					throw RunTimeError(InFileName);
					}
				}
				break;
		case 2:   	os << _Options << " " <<  InFileName;  
				 	cout << os.str().c_str() << endl;

				if (!_DisplayMode) {
				if (Runcmd(os.str().c_str())>0){
					ResetBit(); 
					throw RunTimeError(InFileName);
					}
				}
				break;

		case 3:	switch 		(itr->get_number()) {
				case 8:     os << itr->get_name() << " " << InFileName << endl;
							break;
				case 16: 	os << itr->get_name() << " " << *oFilename << " "
					   		<< InFileName << endl;
							break;
				default: 	ResetBit(); 
							throw RunTimeError(InFileName);
							break;
					}	 
				 	cout << os.str();

				if  (!_DisplayMode) {
				if  (Runcmd(os.str().c_str())<0){
					ResetBit(); 
					throw RunTimeError(InFileName);
					}
				}
				break;
	default: 	ResetBit(); 
				throw RunTimeError(InFileName);
				break;
	}
return tFilename;	
}

// -------------------------------------------------------------------------------------
//   Lastargs:  Store command line parameters used during F8 view configuration 
//   			save build arguments so that releasing F8 key and selecting F10
//   			allows the program to be built without having to re-enter args.
// -------------------------------------------------------------------------------------
auto_ptr<string> Vkeys::Lastargs ( const std::string &InCommandLine){
				auto_ptr<string> bCmdLine (new string(InCommandLine));   
			
					auto_ptr < string > FileName  (new string);
					FileName = ReadBuildConfig ("cmdline.arg");
					bitset<Keys>  FunKey (string(FileName->c_str()));
					auto_ptr <string> TempFile (new string("/tmp/vm.23283493"));

		 if (!FunKey.test(F8)) { 							
		 	if (FunKey.test(F7)) { 							
					FunKey.reset(F7);
					FileName -> clear(); 
					FileName->append(FunKey.to_string()); 
					UpdateCmdLine (*FileName); 			

					auto_ptr < string > TmpString (new string);
					ifstream fin (TempFile -> c_str());		
			if (fin.fail()) {
					ResetBit(); 
					throw FileReadError(TempFile -> c_str());
					}

					bCmdLine -> clear();
			while ( fin >> *bCmdLine ) {			
					TmpString -> append (*bCmdLine);
					TmpString -> append (" ");		
					}
					fin.close();

					bCmdLine -> clear();
			if (TmpString -> size() > 0)  {  		
					*bCmdLine = *TmpString;			
					string::size_type  nospaces = bCmdLine->find_first_not_of(" \t\n");
					bCmdLine->erase(0,nospaces);   
					nospaces = bCmdLine->find_last_not_of(" \t\n");
					bCmdLine->erase(nospaces+1);  
					}

					int unl = unlink(TempFile->c_str());	 // if we can't delete temp file
			if (unl) {										 // clear contents of the file
				ofstream fout(TempFile -> c_str(),ios_base::trunc);  
				fout.close();
				}
			}
		 } else  { 									

			if (FunKey.test(F7)) {					
				if (bCmdLine -> size() > 0) {   
					ofstream fout(TempFile -> c_str(),ios_base::trunc);   

			if (fout.fail()) {
					ResetBit(); 
					throw FileOpenError(TempFile -> c_str());
					}
					fout << *bCmdLine;				
					fout.close();
					}
					auto_ptr < string > TmpString (new string);
					ifstream fin (TempFile -> c_str());	

			if (fin.fail()) {
					ResetBit(); 
					throw FileReadError(TempFile -> c_str()); 	 
					}
					bCmdLine -> clear();

			while ( fin >> *bCmdLine ) {			
					TmpString -> append (*bCmdLine);
					TmpString -> append (" ");		
					}
					fin.close();
					bCmdLine -> clear();

			if (TmpString -> size() > 0) {  	
					*bCmdLine = *TmpString;			
					string::size_type  nospaces = bCmdLine->find_first_not_of(" \t\n");
					bCmdLine->erase(0,nospaces);   // trim any leading whitespace
					nospaces = bCmdLine->find_last_not_of(" \t\n");
					bCmdLine->erase(nospaces+1);   // trim any trailing whitespace
					}

		} else  {									
					FunKey.set(F7);		
					FileName -> clear();			
					FileName->append(FunKey.to_string()); 
					UpdateCmdLine (*FileName);      
					ofstream fout(TempFile -> c_str());	  

			if (fout.fail()) {
					ResetBit(); 
					throw FileOpenError(TempFile -> c_str());
					}
					fout << *bCmdLine;				
					fout.close();				
					} 
				} 
				
return bCmdLine;
}



// ---  FUNCTION BUILDMAINFILE (Multiple Files) ----------------------------------------
//  		    Build Main Source File along with additional program files
// -------------------------------------------------------------------------------------
int  Vkeys::BuildMainFile(const std::string &InCommandLine) {
auto_ptr<string> bCommandLine(new string(InCommandLine));   
struct stat MainFileBuffer,MainObjBuffer,MainExeBuffer;

				vector<time_t>fileTime;
				vector<time_t>::iterator tm;
				std::string TempString;
				std::string::size_type idx;
				get_version(); 

			if (stat(_MainFileSrc.c_str(),&MainFileBuffer)<0) {
			    ResetBit(); 
				throw FileOpenError(_MainFileSrc.c_str());	
				}

			//----------------------------------------------------------------------
			// 		Initialize modification times to zero for any file not yet created.
			//----------------------------------------------------------------------
			if (stat(_MainFileSrc.c_str(),&MainFileBuffer)<0)
				{ MainFileBuffer.st_mtime=0; }

			if (stat(_MainFileObj.c_str(),&MainObjBuffer)<0)
				{ MainObjBuffer.st_mtime=0; }

			if (stat(_MainFileExe.c_str(),&MainExeBuffer)<0)
				{ MainExeBuffer.st_mtime=0; }

			//----------------------------------------------------------------------		
			//  	Obtain the list of filenames from a project file
			//----------------------------------------------------------------------  	
                idx = bCommandLine -> find(".prj");

            if (idx != std::string::npos) {	    
				_BuildFile = *Getenv("PWD");
				_BuildFile += "/" + *bCommandLine;
                std::ifstream fin(_BuildFile.c_str(),std::ios::in);

            if (fin.fail()) {
				ResetBit(); 
                throw FileOpenError(InCommandLine.c_str());
                }
                getline(fin,TempString);
                fin.clear();
                fin.close();
                _BuildFile=TempString;

             if (!fin.good()) {
				 ResetBit(); 
				throw FileReadError(InCommandLine.c_str());
				}
            } else 
			//----------------------------------------------------------------------		
			//		Obtain the list of filenames from build prompt
			//----------------------------------------------------------------------		

			{	_BuildFile= *bCommandLine;  }
				 auto_ptr < string > vname  (new string);
			  	 vname = ReadBuildConfig ("cmdline.arg");
	  			bitset<Keys>  FunKey (string(vname->c_str()));
			
			if (!FunKey.test(F4)) {
				ResetBit(); 
				throw RunTimeError(_MainFileSrc.c_str());   
				}
			   	unsigned status = Makefile(_BuildFile);    
		
			//----------------------------------------------------------------------
			// 		Compile main file according to modification time
			//----------------------------------------------------------------------
				fileTime.push_back(MainFileBuffer.st_mtime);
				fileTime.push_back(MainObjBuffer.st_mtime);
				tm = max_element(fileTime.begin(),fileTime.end());


			if ( *tm == MainExeBuffer.st_mtime ) {
				status = 0;
			} else	

			if ( *tm  > MainExeBuffer.st_mtime ) {
				Bcompile(_MainFileSrc);               
				status=1;
				}

		   if (_DisplayMode){   
				fileTime.push_back(MainFileBuffer.st_mtime);
				fileTime.push_back(MainObjBuffer.st_mtime);
				tm = min_element(fileTime.begin(),fileTime.end());

			if ( *tm  < MainExeBuffer.st_mtime ) {
				 Bcompile(_MainFileSrc);               
				status =1;
			   }
			}

			while (fileTime.size() > 0) { 
				fileTime.erase(fileTime.begin());
				}
			//----------------------------------------------------------------------
			//  	Link according to file modification times
			//----------------------------------------------------------------------
			
                std::stringstream obstr(_BuildFile);

            while (obstr >>  TempString) {
                stat(TempString.c_str(),&MainObjBuffer);
				fileTime.push_back(MainObjBuffer.st_mtime);
				}
				tm = max_element(fileTime.begin(),fileTime.end());

			if ( *tm  > MainExeBuffer.st_mtime ) {
				status=1;
				}

			if (status) {
             status =   Blink(_MainFileSrc);
			} else {
				ResetBit(); 
				cout << nTab << _MainFileExe << " is up to date!\n";
				}

return status;
}

// ------- FUNCTION BUILD_LUA_BIN -------------------------------------------------------
// 			Create a lua binary file using the luac compiler
// 			Input:  lua script file
// 			Output  lua binary file  and lua script file
// 			        Original lua script file returned unchanged
//------------------------------------------------------------------------------------- 			
int  Vkeys::BuildLuaBin(const std::string& CmdLine="") {
	
struct stat MainFileBuffer,MainBinBuffer;
vector<time_t>fileTime;
vector<time_t>::iterator tm;
ostringstream os;
string FileExtent;



					_Options 	= "_options";
					_Index 		= _MainFileSrc.rfind('.');     
					FileExtent.assign(_MainFileSrc,++_Index,_MainFileSrc.size());   
					_Index = GetFileExt(FileExtent);
					FileExtent+=_Options; 					
					_Options = *ReadBuildConfig(FileExtent);  
					FileExtent = _MainFileSrc;
					Sreplace(FileExtent,"lua","bin");       
				   _Index = _Options.rfind(' ');
				   
			//----------------------------------------------------------------------
			// 		Initialize modification times to zero for any file not yet created.
			//----------------------------------------------------------------------
			if (stat(_MainFileSrc.c_str(),&MainFileBuffer)<0)
					{ MainFileBuffer.st_mtime=0; }

			if (stat(FileExtent.c_str(),&MainBinBuffer)<0)
					{ MainBinBuffer.st_mtime=0;  }

			//----------------------------------------------------------------------
			// 		Create a lua.bin file according to file modification time
			//----------------------------------------------------------------------
					fileTime.push_back(MainFileBuffer.st_mtime);
					fileTime.push_back(MainBinBuffer.st_mtime);
					tm = max_element(fileTime.begin(),fileTime.end());

			if ( *tm  > MainBinBuffer.st_mtime ) {

			if (_Options[_Index+2] == 'o') {        
			  		os << _Options << " " << FileExtent << " " << _MainFileSrc << " " << CmdLine << ends;
				} else {
				   	os << _Options << " " << _MainFileSrc << " " << CmdLine << ends;
			 		}
				} else {

			if (_Options[_Index+2] == 'o') {         
					os << "";

			if (isXterm) {
			  		cout <<  nTab << Red  << FileExtent.c_str() << Off << " is up to date! " << endl;
				} else {
			  		cout << "\n\t" << FileExtent.c_str() << " is up to date! " << endl;
					}
				} else {
				   	os << _Options << " " << _MainFileSrc << " " << CmdLine << ends;
				   	}
				}

			if (isXterm) {
					std::cout << nTab << Blue << os.str().c_str() << Off << "\n" << std::endl;
				} else {
					std::cout << "\n\t" << os.str().c_str() << std::endl;
				}

			if (Runcmd(os.str().c_str())<0){
					ResetBit(); 
					throw RunTimeError(_MainFileSrc);
					}

return 0;
}


// ---  FUNCTION  BUILDMAINFILE (Single File) ------------------------------------------
//  			Build the Main Source File entered on the command line.
// ------------------------------------------------------------------------------------- 
int  Vkeys::BuildMainFile(void) {
	
				struct stat MainFileBuffer,MainObjBuffer,MainExeBuffer;
				vector<time_t>fileTime;
				vector<time_t>::iterator tm;
				unsigned status = 0;
				get_version();
			
			if (stat(_MainFileSrc.c_str(),&MainFileBuffer)<0){
				ResetBit(); 
				throw FileOpenError(_MainFileSrc.c_str());
				}
			//----------------------------------------------------------------------
			// 		Initialize modification times to zero for any file not yet created.
			//----------------------------------------------------------------------
			if (stat(_MainFileSrc.c_str(),&MainFileBuffer)<0)
				{ MainFileBuffer.st_mtime=0; }

			if (stat(_MainFileObj.c_str(),&MainObjBuffer)<0)
				{ MainObjBuffer.st_mtime=0;  }

			if (stat(_MainFileExe.c_str(),&MainExeBuffer)<0)
				{ MainExeBuffer.st_mtime=0;  }


			//----------------------------------------------------------------------
			// 		Compile main file according to modification time
			//----------------------------------------------------------------------
				fileTime.push_back(MainFileBuffer.st_mtime);
				fileTime.push_back(MainObjBuffer.st_mtime);
				tm = max_element(fileTime.begin(),fileTime.end());
				auto_ptr < string > vname  (new string);
				vname = ReadBuildConfig ("cmdline.arg");
				bitset<Keys>  FunKey (string(vname->c_str()));

			if (!FunKey.test(F4)) {
				ResetBit(); 
				throw RunTimeError(_MainFileSrc.c_str());      
				}
			 	
			if ( *tm == MainExeBuffer.st_mtime ) {
				status = 0;
			} else 
				
			if ( *tm  > MainExeBuffer.st_mtime ) {
				Bcompile(_MainFileSrc);     
				status=1;
				}

			if (_DisplayMode) {
				fileTime.push_back(MainFileBuffer.st_mtime);
				fileTime.push_back(MainObjBuffer.st_mtime);
				tm = min_element(fileTime.begin(),fileTime.end());

			if ( *tm  < MainExeBuffer.st_mtime ) {
				Bcompile(_MainFileSrc);     
				status=1;
				}
			}

			//----------------------------------------------------------------------
			//		Check and link accordingly
			//----------------------------------------------------------------------
			if (status) {
				Blink(_MainFileSrc);
			} else { 
				ResetBit(); 
				cout << nTab << _MainFileExe << " is up to date !\n";
			}

return status;
}


// ---  FUNCTION  CHECKFILETIMES -------------------------------------------------------
//             Checks the  file access and modification times. 
//             Returns bool true  if times are updated.
// -------------------------------------------------------------------------------------
//                
bool Vkeys::CheckFileTimes(const string &HeaderName,const string &SourceName) {

            struct stat HeaderBuffer,SourceBuffer;
            struct utimbuf timebuf;
            bool status = false;
            string FileNameExt;
            //----------------------------------------------------------------------
            // If the header or source file does not exist --- quit
            //----------------------------------------------------------------------
            if (stat(HeaderName.c_str(),&HeaderBuffer)<0) {
				ResetBit(); 
                throw FileStatError(HeaderName.c_str());
                }

            if (stat(SourceName.c_str(),&SourceBuffer)<0) {
				ResetBit(); 
                throw FileStatError(SourceName.c_str());
                }
            //----------------------------------------------------------------------
            // If any Header file has a more recent time than it's corresponding 
            // source file. Change source file time and set status. To prevent multi
            // builds where the header file time would constantly appear more recent.
            //----------------------------------------------------------------------
            if (HeaderBuffer.st_mtime > SourceBuffer.st_mtime) {
                timebuf.actime  = HeaderBuffer.st_atime;
                timebuf.modtime = HeaderBuffer.st_mtime;

            if (utime(SourceName.c_str(),&timebuf)<0) {
				ResetBit(); 
                cout << nTab << "Unable to change times on " << SourceName.c_str();
                exit(1);
                }
                status = true;
            }

return status;
}




// ---  FUNCTION  MAKEFILE ------------------------------------------------------------
// Description:  Makefile parses the command line, builds a vector of strings grouped by each
// 				 file extension type. Determines which files require assembling by examining
// 				 file times. After any assembling has been performed, returns the link status
// 				 along with a list of object filenames for linking.
// -------------------------------------------------------------------------------------
int Vkeys::Makefile(string &InCommandLine) {
	
				vector<time_t>fileTime;
				vector<time_t>::iterator tm;
				stringstream IoStream; 
				vector <string>Vec(12); 
				list<string> List; 
				list<string>::iterator itr;
				string::size_type idx; 
				string FileNameExt,TempHdrString;
				struct stat HeaderBuffer,ObjectBuffer,SourceBuffer; 
				struct stat MainFileBuffer,MainObjBuffer,MainExeBuffer; 
				bool result = false;
				int status 	= 0;
				//----------------------------------------------------------------------
				// 		Initialize modification times to zero for any file not yet created.
				//----------------------------------------------------------------------
			if  (stat(_MainFileSrc.c_str(),&MainFileBuffer)<0)
				 MainFileBuffer.st_mtime=0;   

			if  (stat(_MainFileObj.c_str(),&MainObjBuffer)<0)
				 MainObjBuffer.st_mtime=0;  

			if 	(stat(_MainFileExe.c_str(),&MainExeBuffer)<0)
				 MainExeBuffer.st_mtime=0;  

				//----------------------------------------------------------------------
				//		For each file on command line. If we can't stat -- exit.
				//		If we have no file suffix exit. If ok, map its extension to an int.
				//----------------------------------------------------------------------
				stringstream InputStream(InCommandLine);

				InCommandLine.clear();
		  while (InputStream >> Vec[TemporaryObject]) {

			if 	(stat(Vec[TemporaryObject].c_str(),&ObjectBuffer)<0){
				ResetBit(); 
				throw FileStatError(Vec[TemporaryObject].c_str()); 
				}
				idx=Vec[TemporaryObject].find('.');					   

			if	(idx == std::string::npos) {
				ResetBit(); 
				throw FileIndexError(Vec[TemporaryObject].c_str()); 
			}

				Vec[TempFileExtent].assign(Vec[TemporaryObject],	  
				++idx,Vec[TemporaryObject].size());
				idx=GetFileExt(Vec[TempFileExtent]);				  


				//----------------------------------------------------------------------
				//		Sort files by type where  [1,2] are c/c++.  [3] is assembly.
				//		[5] is c-cpp local headers.  [6] is ince and macro files.
				//		Create a string of object filenames in IncommandLine.
				//		Any unknown file suffixes will force a program exit
				//----------------------------------------------------------------------
           switch(idx) {

            case 1:
            case 2:     Vec[SourceFileList]+=Vec[TemporaryObject]+" ";
                        Vec[TemporaryObject].replace(Vec[TemporaryObject].size()-
                        Vec[TempFileExtent].size(),
                        Vec[TempFileExtent].size(),"o");
                        Vec[ObjectFileList]+=Vec[TemporaryObject]+" ";
						Vec[CppTempObjList]+=Vec[TemporaryObject]+" ";
                        break;

            case 3:     Vec[AssemblyFileList]+=Vec[TemporaryObject]+" ";
                        Vec[TemporaryObject].replace(Vec[TemporaryObject].size()-
                        Vec[TempFileExtent].size(),
                        Vec[TempFileExtent].size(),"o");
                        Vec[ObjectFileList]+=Vec[TemporaryObject]+" ";
						Vec[AsmTempObjList]+=Vec[TemporaryObject]+" ";
                        break;

            case 5:     Vec[HeaderFileList]+=Vec[TemporaryObject]+" ";
                        break;

            case 6:     Vec[IncludeFileList]+=Vec[TemporaryObject]+" ";
                        break;

			case 7:     Vec[ObjectFileList]+=Vec[TemporaryObject]+" ";
						break;

            default:    ResetBit();
						throw BadFileName(Vec[TemporaryObject].c_str());
                        break;
                        }

                }   // End of command line parser


				//----------------------------------------------------------------------
				//		InCommandLine contains a complete list of object filenames for linking.
				//----------------------------------------------------------------------
						InCommandLine=Vec[ObjectFileList];

				//----------------------------------------------------------------------
				// 		First pass deals with the header(.H)  and C/C++ files. 
				// 		Pass two is for Nasm/Gnu[gas] and  include/macro files.
				//----------------------------------------------------------------------

			for (int count=0; count<2; count++) { 	
			
				//----------------------------------------------------------------------
				// 		IF THERE ARE NO HEADER FILES BUT THERE ARE SOURCE FILES 
				//----------------------------------------------------------------------

			if ((Vec[HeaderFileList].size() == 0)&&(Vec[SourceFileList].size() > 0)) { 
				
				//----------------------------------------------------------------------
				//		Build streams of object and source files. Place in List source
				//		files that require building.
				//----------------------------------------------------------------------

						stringstream ObjectStream(Vec[CppTempObjList]); 
						stringstream SourceStream(Vec[SourceFileList]); 


			while 	(( ObjectStream >> Vec[ObjectFileName]) && ( SourceStream >> Vec[SourceFileName])) {   
						status = 0;

			if (stat(Vec[SourceFileName].c_str(),&SourceBuffer)<0)  
						SourceBuffer.st_mtime = 0; 

			if (stat(Vec[ObjectFileName].c_str(),&ObjectBuffer)<0)   
						ObjectBuffer.st_mtime = 0;                       


			if (SourceBuffer.st_mtime > ObjectBuffer.st_mtime) { 
						List.insert(List.end(),Vec[SourceFileName]);       
						status = 1;
						}

				//----------------------------------------------------------------------
				//      If DisplayMode show build configuration
				//----------------------------------------------------------------------
				
			if (_DisplayMode) { 

			if (SourceBuffer.st_mtime > ObjectBuffer.st_mtime) { 
						List.insert(List.end(),Vec[SourceFileName]);       
						status = 1;
						}

						fileTime.push_back(MainFileBuffer.st_mtime);
						fileTime.push_back(MainObjBuffer.st_mtime);
						tm = min_element(fileTime.begin(),fileTime.end());

			if ( *tm  < MainExeBuffer.st_mtime ) {
						status=1;
						}
					}   	
				} 			 


						fileTime.push_back(MainFileBuffer.st_mtime);
						fileTime.push_back(MainObjBuffer.st_mtime);
						tm = max_element(fileTime.begin(),fileTime.end());

			if ( *tm  > MainExeBuffer.st_mtime ) {
						status=1;
						} 

			else  {	status=0; }

				} else  
				//----------------------------------------------------------------------
				// 		IF THERE ARE BOTH HEADER FILES AND  SOURCE FILES 
				//----------------------------------------------------------------------

			if ((Vec[HeaderFileList].size() > 0)&&(Vec[SourceFileList].size() > 0)) { 
						stringstream HeaderStream(Vec[HeaderFileList]);  

			while (HeaderStream >> Vec[HeaderFileName]) {    
						stringstream ObjectStream(Vec[CppTempObjList]); 
						stringstream SourceStream(Vec[SourceFileList]); 

			while ((ObjectStream >> Vec[ObjectFileName])&&(SourceStream	>> Vec[SourceFileName])) { 

			if (stat(Vec[HeaderFileName].c_str(),&HeaderBuffer)<0)
						HeaderBuffer.st_mtime = 0; 

			if (stat(Vec[ObjectFileName].c_str(),&ObjectBuffer)<0) 
						ObjectBuffer.st_mtime = 0; 

			if (stat(Vec[SourceFileName].c_str(),&SourceBuffer)<0) 
						SourceBuffer.st_mtime = 0; 

				//----------------------------------------------------------------------
				//		Search each source file for corresponding header or include file
				//----------------------------------------------------------------------

						TempHdrString = Vec[HeaderFileName]; 
						TempHdrString = "\""+TempHdrString+"\"";
						result = Strstr(Vec[SourceFileName],TempHdrString);    

			if (result) {		
						status = CheckFileTimes(Vec[HeaderFileName],Vec[SourceFileName]); 

			if (_DisplayMode) {
						List.insert(List.end(),Vec[SourceFileName]); 
						status = 1;

			if (( SourceBuffer.st_mtime < ObjectBuffer.st_mtime) ||
				( HeaderBuffer.st_mtime < SourceBuffer.st_mtime)) {

						List.insert(List.end(),Vec[SourceFileName]);  
						status = 1;	
						} 
					} 
				//----------------------------------------------------------------------
				//		If header is found and if status, place file in list for building
				//----------------------------------------------------------------------

			if (status) { 			
						List.insert(List.end(),Vec[SourceFileName]); 
						status = 1;
						}

			if (( SourceBuffer.st_mtime > ObjectBuffer.st_mtime) ||
				( HeaderBuffer.st_mtime > SourceBuffer.st_mtime)) { 
							List.insert(List.end(),Vec[SourceFileName]);  
							status = 1;	
							} 
						} 
					}  					
				}             		 						  
			}  else 
				//----------------------------------------------------------------------
				// 		If there are header files but no secondary source files 
				//----------------------------------------------------------------------

		   	if ((Vec[HeaderFileList].size() > 0)&&(Vec[SourceFileList].size() == 0)) { 
						vector<time_t>fileTime;
						vector<time_t>::iterator tm;

				//----------------------------------------------------------------------
				//		No source files so use the main filename
				//----------------------------------------------------------------------
						Vec[SourceFileName] = _MainFileSrc.c_str();  
						stringstream HeaderStream(Vec[HeaderFileList]);

			while (HeaderStream >> Vec[HeaderFileName]) {  

						TempHdrString = Vec[HeaderFileName]; 
						TempHdrString = "\""+TempHdrString+"\"";

				//----------------------------------------------------------------------
				// 		Search each header/include file against the main source file 
				//----------------------------------------------------------------------

						result = Strstr(_MainFileSrc.c_str(),TempHdrString);   

			if (result) {    	
			 			status = CheckFileTimes(Vec[HeaderFileName],Vec[SourceFileName]); 

			if (status ) { 									  
						status = 1;	

			} else { 

			if (_DisplayMode) { 
						fileTime.push_back(MainFileBuffer.st_mtime);
						fileTime.push_back(MainObjBuffer.st_mtime);
						tm = min_element(fileTime.begin(),fileTime.end());

			if ( *tm  < MainExeBuffer.st_mtime || MainObjBuffer.st_mtime == 0) {
						status = 1;	
							}
						} 

						fileTime.push_back(MainFileBuffer.st_mtime);
						fileTime.push_back(MainObjBuffer.st_mtime);
						tm = max_element(fileTime.begin(),fileTime.end());

			if ( *tm  > MainExeBuffer.st_mtime || MainObjBuffer.st_mtime == 0) {
						status = 1;	
						}
					} 	
				} 		
			} 		

			} 		//  	END OF IF-ELSE-LOOPS


						Vec[SourceFileList].swap(Vec[AssemblyFileList]); 
						Vec[HeaderFileList].swap(Vec[IncludeFileList]);
						Vec[CppTempObjList].swap(Vec[AsmTempObjList]);

			}		//		End of FOR LOOP	
						List.sort();            
						List.unique();		   
				
			for (itr=List.begin();itr!=List.end();++itr) { 
						Bcompile(*itr);
						status = 1;
						}

return status;		 		
} 

}  // namespace edm



