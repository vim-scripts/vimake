//======================================================================================
//   
//   		Filename:  vidbug.cc
//       Description:  Source code for the multi language vim-gvim vimake program 
//
//           $Id: vidbug.cc,v 1.2 2010/10/16 22:56:39 mike Exp $
//           $Revision: 1.2 $
//
//	 Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>            
//	                                                                          
//	 This file is free software; as a special exception the author gives      
//	 unlimited permission to copy and/or distribute it, with or without       
//	 modifications, as long as this notice is preserved.                      
//	                                                                          
//	 This program is distributed in the hope that it will be useful, but      
//	 WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//	 implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//	 
//======================================================================================
#include "vdebug.h"
using   namespace edn;
using   namespace edm;
bool    edm::isXterm;




int main(int argc,char *argv[]){
Error <string>E;




			try {

					auto_ptr <string> CmdLine (new string(getenv("TERM")));
					*CmdLine  == "xterm" ? isXterm = true : isXterm = false;

			if  (argc != 2) throw BadFileArgs();
					const auto_ptr < string > FileName (new string (argv[argc - 1]));
					Vidbug D(*FileName); 
					D->Validity(*FileName); 
					auto_ptr <string> DebugFileType (D.ReadDebuggers("debuggers"));

			if  (DebugFileType -> size()==0) 
					throw out_of_range("debuggers file is empty!");
				
					std::string::size_type index = count(DebugFileType->begin(),DebugFileType->end(),' ');
					
			if  (index >= 1){
					std::istringstream in_stream (*DebugFileType);
					auto_ptr <string> selection (new string("Select Debugger\n"));
					isXterm == true ? cout << Blue << *selection : cout <<nTab << *selection;
					int db = 1;
					std::vector<std::string>Mdebug(4);

		    while (in_stream >> *DebugFileType) {
					Mdebug.push_back(*DebugFileType);
					Dual<int,string> DebugMenu;
					DebugMenu -> Show (db++,DebugFileType -> c_str());  
					}

					DebugFileType -> clear();
					E->Mesg("\n\t\b\bEnter No: ");
					std::cin >> db;

					std::vector<std::string>::iterator itr;
			for (itr=Mdebug.begin();itr!=Mdebug.end();++itr,--db)

			if  (db == -3)  *DebugFileType += *itr; 
				}

			if  (DebugFileType -> empty()) {
					E->Quit("Bad selection.\n");
					}
					D->DebugFile(*DebugFileType);


			} catch (out_of_range& e){
					E->Quit(e.what(),"\n");
			} catch (const FileError& e) {
					E->Mesg(e.what());
			} catch ( ... ) {
					E->Quit("Unrecognized exception");
					}


return 0;
}
