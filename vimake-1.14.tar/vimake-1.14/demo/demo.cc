#include <iostream>
#include <sstream>
#include <string>
using std::string;
using std::ostringstream;

///   	Vimake demonstration of a mixed language build.
/// 		using nasm,gas(as),gcc and g++
///     
///     Mike Lear 2009

/// 	To build: 	vi	demo.cc
///		cmdline args: sysinf.asm cpu.asm cpuid.s id.c to_upper.asm inf.c
/// 	or
///     cmdline args: demo.prj

extern "C" { 		///     Declare the functions as external "C" linkage.
	int   to_upper(const string& str,int ); // to_upper.asm   (nasm)
	char  *cpuidfunc(void);  				// cpu.asm        (nasm)
	char  *proc_id(void);    				// cpuid.s		  (as)  
	int   id(void);          				// id.c           (c)
	int   sysinf(void);      				// sysinf.asm     (nasm) 
	int   inf(void);         				// inf.c          (c)
	int  typword(void);      				// typword.s      (as)
}
 
int main() {
string cmdline;		// Declare some variables
unsigned int length;
ostringstream ostr;

			inf();		

			std::cout << "\t// nasm function";
			sysinf();

			std::cout << "\n\t// c function\n";
			id();

			ostr  << "\n\tThe processor is " << cpuidfunc() << " // nasm function";
			ostr  << "\n\tThe processor is " << proc_id()   << " // gas(as) function\n";
			std::cout << ostr.str().c_str();

			std::cout <<"\n\tEnter a sentence: ";
			getline(std::cin,cmdline);
			std::cout << "\n\tYour sentence changed to upper case.\n";

			length = cmdline.size();     		
			++length;
			to_upper(cmdline.c_str(),length); 	// pass a string and an int to nasm

			typword();							// gas(as) function
			std::cout << "\tBack in C++ -- End of demonstration -- exiting...!\n";

return(0);
}
